#include "char_key_conv.h"
#include "setup.h"
#include "sign_algorithm.h"
#include "verify.h"

// should be commented in the main

extern inline void pk_to_c_64(uint64_t *c, const public_key *pk);
extern inline void c_to_pk_64(public_key *pk, const uint64_t *c);

extern inline void sk_to_c_64(uint64_t *c, const secret_key *sk);
extern inline void c_to_sk_64(secret_key *sk, const uint64_t *c);

int crypto_sign_keypair(unsigned char *pk, unsigned char *sk) {
  memset(pk, 0x00, CRYPTO_PUBLICKEYBYTES);
  memset(sk, 0x00, CRYPTO_SECRETKEYBYTES);

  // get a seed for the key setup
  unsigned char seed[32];
  randombytes(seed, 32);

  // create the structures
  secret_key *sk2;
  init_secret_key(&sk2);
  public_key *pk2;
  init_public_key(&pk2);

  secret_key_setup(sk2, seed);

  key_setup(pk2, sk2);

  // export to char
  pk_to_c_64((uint64_t *)pk, pk2);

  sk_to_c_64((uint64_t *)sk, sk2);

  // delete structures
  free_secret_key(sk2);
  free_public_key(pk2);

  // we shouldn't ever get a problem with generation
  return 0;
}

int crypto_sign(unsigned char *sm, unsigned long long *smlen,
                const unsigned char *m, unsigned long long mlen,
                const unsigned char *sk) {
  // let's not sign emptiness
  if (!mlen) {
    // fprintf(stderr, "Don't sign empty messages\n");
    return -1;
  }

  memset(sm, 0x00, CRYPTO_BYTES);

  // create the structures
  secret_key *sk2;
  init_secret_key(&sk2);
  message *hm;
  init_message(&hm);
  signature *s;
  init_signature(&s);
  message *m_cpy;
  init_message(&m_cpy);

  // we sign a copy to avoid modification of the message
  c_to_sk_64(sk2, (uint64_t *)sk);

  // hash & cpy
  hashed_message(hm, m, mlen);
  for (unsigned int i = 0; i < _DIM_; i++) {
    m_cpy->dat[i] = hm->dat[i];
  }

  // sign
  sign(m_cpy, s, sk2);

  // recover the signature in chars
  sgn_to_c_64((uint64_t *)sm, s);
  // put the message into the signature
  *smlen = CRYPTO_BYTES + mlen;
  for (size_t i = 0; i < mlen; i++) {
    sm[i + CRYPTO_BYTES] = m[i];
  }

  // free the memory
  free_secret_key(sk2);
  free_message(hm);
  free_message(m_cpy);
  free_signature(s);

  // unless you get a faulty system
  // you should be able to sign anything since we hash any non-empty message to
  // the message space
  return 0;
}

int crypto_sign_open(unsigned char *m, unsigned long long *mlen,
                     const unsigned char *sm, unsigned long long smlen,
                     const unsigned char *pk_c) {
  int res;

  // extract the message from sm, put it into m
  *mlen = smlen - CRYPTO_BYTES;
  for (size_t i = 0; i < *mlen; i++) {
    m[i] = sm[i + CRYPTO_BYTES];
  }
  // create the structures
  signature *s;
  init_signature(&s);
  message *msg;
  init_message(&msg);
  public_key *pk;
  init_public_key(&pk);

  hashed_message(msg, m, *mlen);

  c_to_pk_64(pk, (uint64_t *)pk_c);

  c_to_sgn_64(s, (uint64_t *)sm);

  // verify (the output of verify can indicate the type of error)
  // this can be changed in the source code
  res = verify(msg, s, pk);

  // free the memory
  free_public_key(pk);
  free_message(msg);
  free_signature(s);

  return res;
}
