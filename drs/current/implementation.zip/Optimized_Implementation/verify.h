#ifndef VERIFY_H
#define VERIFY_H

#include "crypto_struct.h"

int64_t verify(message *m, signature *s, public_key *pk) {
  int64_t tmp, tmp2, tmp3, t_nonzero = 1, q_nonzero = 1;
  int64_t rP[_DIM_], r[_DIM_], q[_DIM_], t[_DIM_];

  int64_t del_log = Log2_64(pk->log_reduc) - 1;
  int64_t mask_delta = UINT64_C(-1) >> (64 - del_log);

  // check for max norm first
  tmp = 0;
  for (unsigned int i = 0; i < _DIM_; i++) {
    tmp |= s->dat[i] >= _D_BOUND_;
    tmp |= s->dat[i] <= -_D_BOUND_;
  }
  if (tmp) {
    // fprintf(stderr, "signature not low enough\n");
    return -1;
  }

  // Loop initialization part
  for (unsigned int i = 0; i < _DIM_; i++) {
    q[i] = (s->k[i]);
    t[i] = m->dat[i] - s->dat[i];
  }
  // loop start
  while (t_nonzero && q_nonzero) {
    // compute the value r to multiply by P

    for (unsigned int i = 0; i < _DIM_; i++) {

      tmp = -(q[i] < 0);
      r[i] = (q[i] ^ tmp) - tmp;  // put into absolute value
      r[i] = (r[i] & mask_delta); // take remainder
      r[i] = (r[i] + tmp) ^ tmp;  // put back into original sign
    }

    // this should stay zero if t reduced itself to 0, and shouldn't overflow
    // (at worst it's the size of the message dividided by p_2 times the
    // dimension)
    t_nonzero = 0;
    // compute rP, then t-rP
    for (unsigned int i = 0; i < _DIM_; i++) {
      rP[i] = 0;
      for (unsigned int j = 0; j < _DIM_; j++) {
        rP[i] += r[j] * pk->dat[i][j];
      }
    }

    // check divisibility
    tmp3 = 0;
    for (unsigned int i = 0; i < _DIM_; i++) {

      tmp2 = t[i] - rP[i];
      tmp = -(tmp2 < 0);
      tmp2 = (tmp2 ^ tmp) - tmp; // put into absolute value
      t[i] = (tmp2 >> del_log);
      t_nonzero += t[i];
      t[i] = (t[i] + tmp) ^ tmp; // put back into original sign
      // tmp2 should have been divisible by _DELTA
      tmp3 |= tmp2 & mask_delta;
    }

    if (tmp3) {
      // fprintf(stderr, "t - rP not divisible by _DELTA\n");
      return -1;
    }

    // this should stay zero if q reduced itself to 0
    // this should also not overflow
    q_nonzero = 0;
    // update q
    for (size_t i = 0; i < _DIM_; i++) {
      tmp2 = q[i] - r[i];
      tmp = -(tmp2 < 0);
      tmp2 = (tmp2 ^ tmp) - tmp;
      tmp2 = (tmp2 >> del_log);
      q[i] = (tmp2 + tmp) ^ tmp;
      q_nonzero += tmp2;
    }
    // another check for invalid terms (one reduced to zero early)
    if (!q_nonzero != !t_nonzero) {
      // fprintf(stderr, "q and t not-zero at the same time\n");
      return -1;
    }
  }
  return 0;
}

#endif // VERIFY_H
