#ifndef _CHAR_KEY_CONV_H
#define _CHAR_KEY_CONV_H

#include "SHAKE512.h"
#include "crypto_struct.h"

#define _SHIFT_PK ((int64_t)1 << (_SIZE_P_COEF))
#define _GET_BIT_PK (_SIZE_P_COEF + 1)

const int32_t _GET_BIT_SK = _BITS_D_BD_DELTA + 1;
const uint32_t _SHIFT_SK = ((int32_t)1 << (_BITS_D_BD_DELTA));

#define _SHIFT_SGN ((int64_t)1 << (_BITS_D_BD))
#define _GET_BIT_SGN (_BITS_D_BD + 1)

/**************************************/
/*                                    */
/*    bit by bit methods              */
/*                                    */
/**************************************/

// function to advance over an array, capturing a certain amount of bits
// returns the corresponding integer in a uint64_t structure
// longer than 64 bits is not implemented yet (but probably not needed)
inline int64_t capture_bits(unsigned char **array, unsigned int *current_bit,
                            unsigned int wanted_bits) {
  if (wanted_bits > 64) {
    fprintf(stderr, "capture-bits: wanted_bits %u is too big (>64)\n",
            wanted_bits);
    return 0;
  }

  unsigned char _masks_add[8] = {1, 2, 4, 8, 16, 32, 64, 128};
  int64_t res = 0;

  for (size_t i = 0; i < wanted_bits; i++) {
    res = (res << 1);
    res += (((**array) & _masks_add[*current_bit]) >> (*current_bit));
    (*current_bit)++;
    if ((*current_bit) == 8) {
      (*array)++;
      (*current_bit) = 0;
    }
  }
  return res;
}

// in the character array, write the number given in reversed bit order
// get the pointer and current bit of the position we want to start writing
inline void write_bits(unsigned char **array, unsigned int *current_bit,
                       unsigned int nb_bits, int64_t bits_to_write) {
  if (nb_bits > 64) {
    fprintf(stderr, "write_bits nb_bits %u is too big (>64)\n", nb_bits);
    return;
  }

  // for deleting bits
  unsigned char _masks_del[8] = {255 - 1,  255 - 2,  255 - 4,  255 - 8,
                                 255 - 16, 255 - 32, 255 - 64, 255 - 128};

  // the buffer, removes bits we don't need
  int64_t buff = ((bits_to_write << (64 - nb_bits)) >> (64 - nb_bits));
  char bit_to_write;

  for (size_t i = 0; i < nb_bits; i++) {
    // if we write into a new position, reset the bit
    (**array) = (**array) & _masks_del[*current_bit];
    bit_to_write = (buff >> (nb_bits - 1 - i)) & 1;
    (**array) += (bit_to_write << (*current_bit));
    (*current_bit)++;
    // resets the char to 0 before doing operation on it
    if ((*current_bit) == 8) {
      (*array)++;
      (*current_bit) = 0;
    }
  }
}

/**************************************/
/*                                    */
/*    Hashing into message space      */
/*                                    */
/**************************************/
// FUNCTION COME WITHOUT INITS

void hashed_message(message *hash_m, const unsigned char *m,
                    unsigned long long mlen) {
  unsigned char bytes[MSG_VECTOR_BYTES];
  // copy of the indexes, to pass to the writing functions
  unsigned int current_bit = 0;
  unsigned char *tmp;
  tmp = (unsigned char *)bytes;
  SHAKE512(m, mlen, bytes, MSG_VECTOR_BYTES);

  int64_t sgn, value;
  for (size_t i = 0; i < _DIM_; i++) {
    sgn = ((capture_bits(&tmp, &current_bit, 1) * 2) - 1);
    value = capture_bits(&tmp, &current_bit, LOG_LIMIT_M);
    (hash_m)->dat[i] = (value * sgn);
  }
}

/**************************************/
/*                                    */
/*           64-bit versions          */
/*                                    */
/**************************************/

// in the uint64_t array, write the bits_to_write to array. array is
// reinitialized to zero little by little.
// get the pointer and current bit of the position we want to start writing
inline void write_bits_64(uint64_t **array, unsigned int *current_bit,
                          unsigned int nb_bits, uint64_t bits_to_write) {

  unsigned int new_curr = (*current_bit) + nb_bits;

  if (new_curr < 64) {
    /* we have space */
    (**array) += (bits_to_write << (64 - nb_bits)) >> *current_bit;
  } else {
    /* we don't, put the rest */
    new_curr = new_curr - 64;
    (**array) += (bits_to_write >> new_curr);
    // increment the pointer and set the whole new 64-bit cell to the rest.
    (*array)++;
    (**array) += (bits_to_write << (64 - new_curr));
  }

  // updates the new current_bit
  *current_bit = new_curr;
}

// function to advance over an array, capturing a certain amount of bits
// returns the corresponding integer in a uint64_t structure
// longer than 64 bits is not implemented yet (but probably not needed)
inline uint64_t capture_bits_64(uint64_t **array, unsigned int *current_bit,
                                unsigned int wanted_bits) {

  uint64_t res = 0;

  unsigned int new_curr = (*current_bit) + wanted_bits;

  if (new_curr < 64) {
    /* we don't need to go reach the next one */
    res = ((**array) << (*current_bit)) >> (64 - new_curr + (*current_bit));
  } else {
    /* we don't need to go reach the next one */
    new_curr = new_curr - 64;
    res = (((**array) << (*current_bit)) >> (*current_bit)) << new_curr;
    // increment the pointer and set the rest of the bits.
    (*array)++;
    res += (**array) >> (64 - new_curr);
  }

  *current_bit = new_curr;
  return res;
}

// print the public key from a uint64_t array
inline void c_to_pk_64(public_key *pk, const uint64_t *c) {
  // copy of the indexes, to pass to the writing functions
  uint64_t *tmp;
  tmp = (uint64_t *)c;
  uint64_t buffer = (*tmp);
  unsigned int curr_bit = 0;
  unsigned int new_curr = _GET_BIT_PK;
  int64_t to_store, shifted;

  // compute the max norm of the matrix (the matrix is already transposed)
  // do this as we read
  uint64_t m_norm[_DIM_];

  for (size_t i = 0; i < _DIM_; i++) {
    size_t j = 0;
    // initialize max_norm value
    m_norm[i] = 0;
    for (; j < _DIM_; j++) {

      new_curr = curr_bit + _GET_BIT_PK;
      to_store = -_SHIFT_PK;

      if (new_curr > 64) {
        /* we need to use everything left, add the top part */
        new_curr = new_curr - 64;
        shifted = (int64_t)(buffer >> (64 - _GET_BIT_PK));
        to_store += shifted;
        // Go to the next 64-bit cell, then add the bottom part
        buffer = *(++tmp);
        shifted = (int64_t)(buffer >> (64 - new_curr));
        to_store += shifted;
        // updates the curr_bit position and flush the left_bits used
        buffer = buffer << new_curr;
        curr_bit = new_curr;
      } else {
        /* we don't need to go reach the next one */
        to_store += (int64_t)(buffer >> (64 - _GET_BIT_PK));
        // updates the value of curr_bit
        curr_bit = new_curr;
        // removes the left_bits used
        buffer = buffer << _GET_BIT_PK;
      }

      pk->dat[i][j] = to_store;
      m_norm[i] += _ABS64_(to_store);
    }
  }

  pk->log_reduc = m_norm[0];
  for (size_t i = 1; i < _DIM_; i++) {
    pk->log_reduc |= m_norm[i];
  }
  pk->log_reduc = (((uint64_t)1) << (62 - Log2_64(pk->log_reduc)));
}

// print the public key in a uint64_t array
inline void pk_to_c_64(uint64_t *c, const public_key *pk) {
  // copy of the indexes, to pass to the writing functions
  uint64_t *tmp;
  tmp = c;
  unsigned int curr_bit = 0;
  unsigned int new_curr;
  int64_t to_stock, shifted;

  // initialize the first element
  *tmp = 0;

  // this one is pretty straightforward, just scan each coefficient
  // and add a value to ensure the positiveness
  for (size_t i = 0; i < _DIM_; i++) {
    for (size_t j = 0; j < _DIM_; j++) {

      // precompute value to stock and the future new_value of current_bit
      new_curr = curr_bit + _GET_BIT_PK;
      to_stock = _SHIFT_PK + pk->dat[i][j];

      if (new_curr > 64) {
        /* we can't put everything, so we need to shift the other way around
         * first */
        shifted = (to_stock >> (_GET_BIT_PK - (64 - curr_bit)));

        (*tmp) |= shifted;
        (tmp)++;
        (*tmp) = 0;
        curr_bit = new_curr - 64;
        shifted = (to_stock << (64 - curr_bit));
        (*tmp) |= shifted;

      } else {
        /* we put everything, we update current_bit and go on */
        curr_bit = new_curr;
        shifted = (to_stock << (64 - new_curr));
        (*tmp) |= shifted;
      }
    }
  }
}

// print the public key in a uint64_t array
inline void sgn_to_c_64(uint64_t *c, const signature *s) {
  // copy of the indexes, to pass to the writing functions
  uint64_t *tmp;
  tmp = c;
  unsigned int curr_bit = 0;
  unsigned int new_curr;
  int64_t to_stock;

  // initialize the first element
  *tmp = 0;

  // this one is pretty straightforward, just scan each coefficient
  // and add a value to ensure the positiveness
  for (size_t i = 0; i < _DIM_; i++) {
    // precompute value to stock and the future new_value of current_bit
    new_curr = curr_bit + _GET_BIT_SGN;
    to_stock = _SHIFT_SGN + s->dat[i];

    if (new_curr < 64) {
      /* we put everything, we update current_bit and go on */
      curr_bit = new_curr;
      (*tmp) |= (to_stock << (64 - new_curr));
    } else if (new_curr > 64) {
      /* we can't put everything, so we need to shift the other way around first
       */
      (*tmp) |= (to_stock >> (_GET_BIT_SGN - (64 - curr_bit)));
      // take care of the rest
      (tmp)++;
      (*tmp) = 0;
      curr_bit = new_curr - 64;
      (*tmp) |= (to_stock << (64 - curr_bit));
    } else {
      curr_bit = 0;
      (*tmp) |= to_stock;
      tmp++;
      (*tmp) = 0;
    }
  }

// transfer q too. We don't worry about the sign as we use the full 64 bits.
// we have two cases : either CRYPTO_BYTES is a multiple of 8, either it's not.
// we do that as long as we have enough 64-bit packs to explore
#if ((CRYPTO_BYTES % 8) != 0)
  // first part of 64-bits integers
  for (size_t i = 0; i < _DIM_ - 1; i++) {
    // top part first
    to_stock = s->k[i];
    (*tmp) |= ((uint64_t)to_stock >> (curr_bit));

    // bottom part then
    (tmp)++;
    (*tmp) = 0;
    (*tmp) |= (to_stock << (64 - curr_bit));
  }
  // the last part is a 8-bit per 8-bit processing
  // complete the last 64-bit pack first
  to_stock = s->k[_DIM_ - 1];
  (*tmp) |= ((uint64_t)to_stock >> (curr_bit));
  (tmp)++;
  (*tmp) = 0;
  // put the rest in 8-bit packs
  uint64_t buf = (to_stock << (64 - curr_bit));
  for (size_t i = 0; i * 8 < curr_bit; i++) {
    ((unsigned char *)tmp)[i] = ((unsigned char *)&buf)[7 - i];
  }
#else
  // every part of q fits in a 64-bit integer
  for (size_t i = 0; i < _DIM_; i++) {
    tmp[i] = s->k[i];
  }
#endif
}

inline void c_to_sgn_64(signature *s, const uint64_t *c) {
  // copy of the indexes, to pass to the writing functions
  uint64_t *tmp;
  tmp = (uint64_t *)c;
  uint64_t buffer = (*tmp);
  unsigned int curr_bit = 0;
  unsigned int new_curr;
  int64_t to_store, shifted;

  // this one is pretty straightforward, just scan each coefficient
  // and substract a value to get back the initial value
  for (size_t i = 0; i < _DIM_; i++) {
    new_curr = curr_bit + _GET_BIT_SGN;
    to_store = -_SHIFT_SGN;

    if (new_curr < 64) {
      /* we don't need to go reach the next one */
      to_store += (int64_t)(buffer >> (64 - _GET_BIT_SGN));
      // updates the value of curr_bit
      curr_bit = new_curr;
      // removes the left_bits used
      buffer = buffer << _GET_BIT_SGN;
    } else if (new_curr > 64) {
      /* we need to use everything left, add the top part */
      new_curr = new_curr - 64;

      shifted = (int64_t)(buffer >> (64 - _GET_BIT_SGN));
      to_store += shifted;
      // Go to the next 64-bit cell, then add the bottom part
      (tmp)++;
      buffer = (*tmp);

      shifted = (int64_t)(buffer >> (64 - new_curr));
      to_store += shifted;

      buffer = buffer << new_curr;
      curr_bit = new_curr;
    } else {
      /* we fill everything and move to a new part */
      curr_bit = 0;
      shifted = (int64_t)(buffer >> (64 - _GET_BIT_SGN));
      to_store += shifted;
      // Go to the next 64-bit cell
      (tmp)++;
      buffer = (*tmp);
    }

    s->dat[i] = to_store;
  }

// we use whole bunches of 64-bits integers
// we have two possibilities : CRYPTO_BYTES is a multiple of 8 or isn't.
#if (CRYPTO_BYTES % 8) != 0
  // use all remaining packs of 64-bits integers
  for (size_t i = 0; i < _DIM_ - 1; i++) {
    to_store = 0;

    /* we need to use everything left, add the top part */
    to_store |= buffer;
    /* now take the bottom part*/
    (tmp)++;
    buffer = (*tmp);
    to_store |= (buffer >> (64 - curr_bit));
    buffer = buffer << curr_bit;

    s->k[i] = to_store;
  }
  // the last part is a 8-bit per 8-bit processing
  // finish the last 64-bit pack first
  to_store = 0;
  to_store |= buffer;
  // now use the last chars
  buffer = 0;
  for (size_t i = 0; i * 8 < curr_bit; i++) {
    ((unsigned char *)&buffer)[7 - i] = ((unsigned char *)(tmp + 1))[i];
  }
  buffer = buffer >> (64 - curr_bit);
  to_store |= buffer;
  s->k[_DIM_ - 1] = to_store;
#else
  // everything fits in a 64-bits integer
  for (size_t i = 0; i < _DIM_; i++) {
    s->k[i] = tmp[i];
  }
#endif
}

inline void sk_to_c_64(uint64_t *c, const secret_key *sk) {

  uint64_t *ptr = c;
  unsigned int curr_bit = 0;
  unsigned int new_curr;
  uint64_t buffer;
  int64_t to_stock;

  // deals with the packs of 64 first
  for (size_t i = 0; i < SEED_SIZE / 8; i++) {
    *ptr = ((uint64_t *)(sk->RandSeed))[i];
    ptr++;
  }

  // now deals with the remaining packs of 8, preload buffer
  if (SEED_SIZE % 8) {
    *ptr = ((uint64_t *)(sk->RandSeed))[(SEED_SIZE / 8) + 1];
    curr_bit = (SEED_SIZE % 8) * 8;
    // clear the overhead
  }

  // the pointer to the first element
  // matrix should be contiguous
  int32_t *sk_ptr = sk->A.dat[0];

  // this one is pretty straightforward, just scan each coefficient
  // and add a value to ensure the positiveness
  for (size_t i = 0; i < _DIM_; i++) {
    // stores the noise before diagonal coefficient
    for (size_t j = 0; j < i; j++) {

      // precompute value to stock and the future new_value of current_bit
      new_curr = curr_bit + _GET_BIT_SK;
      to_stock = _SHIFT_SK + (*sk_ptr);
      sk_ptr++;

      if (new_curr > 64) {
        /* we can't put everything, so we need to shift the other way around
         * first */
        buffer = (to_stock >> (_GET_BIT_SK - (64 - curr_bit)));

        (*ptr) |= buffer;
        (ptr)++;
        (*ptr) = 0;
        curr_bit = new_curr - 64;
        buffer = (to_stock << (64 - curr_bit));
        (*ptr) |= buffer;

      } else {
        /* we put everything, we update current_bit and go on */
        curr_bit = new_curr;
        buffer = (to_stock << (64 - new_curr));
        (*ptr) |= buffer;
      }
    }

    // deal with diagonal coefficient
    new_curr = curr_bit + _GET_BIT_SK;
    to_stock = _SHIFT_SK + (*sk_ptr) - _D_BOUND_;
    sk_ptr++;

    if (new_curr > 64) {
      /* we can't put everything, so we need to shift the other way around
       * first */
      buffer = (to_stock >> (_GET_BIT_SK - (64 - curr_bit)));

      (*ptr) |= buffer;
      (ptr)++;
      (*ptr) = 0;
      curr_bit = new_curr - 64;
      buffer = (to_stock << (64 - curr_bit));
      (*ptr) |= buffer;

    } else {
      /* we put everything, we update current_bit and go on */
      curr_bit = new_curr;
      buffer = (to_stock << (64 - new_curr));
      (*ptr) |= buffer;
    }

    // stores the noise after diagonal coefficient
    for (size_t j = i + 1; j < _DIM_; j++) {

      // precompute value to stock and the future new_value of current_bit
      new_curr = curr_bit + _GET_BIT_SK;
      to_stock = _SHIFT_SK + (*sk_ptr);
      // printf("to put : %d\n", *sk_ptr);
      sk_ptr++;

      if (new_curr > 64) {
        /* we can't put everything, so we need to shift the other way around
         * first */
        buffer = (to_stock >> (_GET_BIT_SK - (64 - curr_bit)));

        (*ptr) |= buffer;
        (ptr)++;
        (*ptr) = 0;
        curr_bit = new_curr - 64;
        buffer = (to_stock << (64 - curr_bit));
        (*ptr) |= buffer;

      } else {
        /* we put everything, we update current_bit and go on */
        curr_bit = new_curr;
        buffer = (to_stock << (64 - new_curr));
        (*ptr) |= buffer;
      }
    }
  }
}

// reversed function, from the character array to the secret keys
// we suppose, of course, that sk is all allocated with full of zeroes
// This function will work if and only if _NB_B_ + _NB_ONES_ > 64
inline void c_to_sk_64(secret_key *sk, const uint64_t *c) {
  // copy of the indexes, to pass to the reading functions

  uint64_t *ptr = (uint64_t *)c;
  unsigned int curr_bit = 0, new_curr;
  uint64_t buffer;
  int64_t to_store, shifted;

  // deals with the packs of 64 first
  for (size_t i = 0; i < SEED_SIZE / 8; i++) {
    ((uint64_t *)(sk->RandSeed))[i] = *ptr;
    ptr++;
  }
  buffer = *ptr;

  // now deals with the remaining packs of 8
  if (SEED_SIZE % 8) {
    curr_bit = (SEED_SIZE % 8) * 8;
    // clear the overhead
    buffer = (*ptr) >> (64 - curr_bit);
    ((uint64_t *)(sk->RandSeed))[(SEED_SIZE / 8) + 1] = buffer;
    // put the buffer back to where it should be
    buffer = (*ptr) << curr_bit;
  }

  // initialize the pointer
  int32_t *sk_ptr = sk->A.dat[0];

  for (size_t i = 0; i < _DIM_; i++) {
    // load before the diagonal coefficient
    for (size_t j = 0; j < i; j++) {

      new_curr = curr_bit + _GET_BIT_SK;
      to_store = -_SHIFT_SK;

      if (new_curr > 64) {
        /* we need to use everything left, add the top part */
        new_curr = new_curr - 64;
        shifted = (int64_t)(buffer >> (64 - _GET_BIT_SK));
        to_store += shifted;
        // Go to the next 64-bit cell, then add the bottom part
        buffer = *(++ptr);
        shifted = (int64_t)(buffer >> (64 - new_curr));
        to_store += shifted;
        // updates the curr_bit position and flush the left_bits used
        buffer = buffer << new_curr;
        curr_bit = new_curr;
      } else {
        /* we don't need to go reach the next one */
        to_store += (int64_t)(buffer >> (64 - _GET_BIT_SK));
        // updates the value of curr_bit
        curr_bit = new_curr;
        // removes the left_bits used
        buffer = buffer << _GET_BIT_SK;
      }

      *sk_ptr = to_store;
      sk_ptr++;
    }

    // do the diagonal coefficient
    new_curr = curr_bit + _GET_BIT_SK;
    to_store = -_SHIFT_SK;

    if (new_curr > 64) {
      /* we need to use everything left, add the top part */
      new_curr = new_curr - 64;
      shifted = (int64_t)(buffer >> (64 - _GET_BIT_SK));
      to_store += shifted;
      // Go to the next 64-bit cell, then add the bottom part
      buffer = *(++ptr);
      shifted = (int64_t)(buffer >> (64 - new_curr));
      to_store += shifted;
      // updates the curr_bit position and flush the left_bits used
      buffer = buffer << new_curr;
      curr_bit = new_curr;
    } else {
      /* we don't need to go reach the next one */
      to_store += (int64_t)(buffer >> (64 - _GET_BIT_SK));
      // updates the value of curr_bit
      curr_bit = new_curr;
      // removes the left_bits used
      buffer = buffer << _GET_BIT_SK;
    }

    *sk_ptr = to_store + _D_BOUND_;
    sk_ptr++;

    // do the after diagonal
    for (size_t j = i + 1; j < _DIM_; j++) {

      new_curr = curr_bit + _GET_BIT_SK;
      to_store = -_SHIFT_SK;

      if (new_curr > 64) {
        /* we need to use everything left, add the top part */
        new_curr = new_curr - 64;
        shifted = (int64_t)(buffer >> (64 - _GET_BIT_SK));
        to_store += shifted;
        // Go to the next 64-bit cell, then add the bottom part
        buffer = *(++ptr);
        shifted = (int64_t)(buffer >> (64 - new_curr));
        to_store += shifted;
        // updates the curr_bit position and flush the left_bits used
        buffer = buffer << new_curr;
        curr_bit = new_curr;
      } else {
        /* we don't need to go reach the next one */
        to_store += (int64_t)(buffer >> (64 - _GET_BIT_SK));
        // updates the value of curr_bit
        curr_bit = new_curr;
        // removes the left_bits used
        buffer = buffer << _GET_BIT_SK;
      }

      *sk_ptr = to_store;
      sk_ptr++;
    }
  }
}

#endif
