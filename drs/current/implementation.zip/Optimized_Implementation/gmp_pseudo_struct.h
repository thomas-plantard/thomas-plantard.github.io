#ifndef _GMP_PSEUDO_STRUCT_H_
#define _GMP_PSEUDO_STRUCT_H_

#include "custom_rand.h"

#if _DIM_==(1108)
#include "tab_1108.h"
#elif _DIM_==(1372)
#include "tab_1372.h"
#elif _DIM_==(1779)
#include "tab_1779.h"
#elif _DIM_==(71)
#include "tab_71.h"
#else
#error "NO PRECOMPUTED TABLE, CANNOT COMPILE"
#endif

// load a constant into a non-constant
void load_const_to_var(ext_uint *var, const cst_ext_uint cst) {
  var->size = cst.size;
  for (size_t i = 0; i < cst.size; i++) {
    var->tab[i] = cst.tab[i];
  }
}

// generate a random value between 0 and the max_sum - 1.
size_t rdm_from_sum_dist(const cst_ext_uint *cst_val_tab,
                         const int const interval[][2], const size_t size) {
  // get the biggest data size
  size_t curr_limb = cst_val_tab[size - 1].size;
  // get the lowest limb
  size_t min_limb = cst_val_tab[0].size;

  // set initial value limits
  uint64_t limit = cst_val_tab[size - 1].tab[curr_limb - 1];
  int nb_bits = Log2_64(limit) + 1;
  // printf("nb_bits : %d\n", nb_bits);
  uint64_t test_val = UniRandExtract(nb_bits);

  // interval position indexes
  size_t curr_low;
  size_t curr_high;
  size_t curr_pos;

  // to avoid recursion, we use a loop.
  // this is for the extremely unlikely critical case of the all equality random
  // (and superior to the maximum value)
  // in that case, everything will be restarted
  size_t reset = 1;
  uint64_t tmp_limb;
  while (reset) {
    // get a test_val that is comparable
    while (test_val > limit) {
      test_val = UniRandExtract(nb_bits);
    }

    curr_limb = cst_val_tab[size - 1].size;
    tmp_limb = limit;

    if (test_val == limit) {
      // equality is a special case to be treated

      // one thing is fixed, which are the intervals of search
      curr_low = interval[curr_limb][0];
      curr_high = interval[curr_limb][1];
      curr_pos = (curr_low + curr_high) >> 1;

      // lower the limb we measure and generate until we find a difference
      // or reach the last limb
      while (test_val == tmp_limb && (curr_limb >= min_limb)) {
        test_val = UniGet64bits_Fast();
        curr_limb--;
        tmp_limb = cst_val_tab[size - 1].tab[curr_limb - 1];
      }

      // all equal case or over the limit. Reboot
      if ((test_val >= tmp_limb)) {
        continue;
      }

      // we generated something in the proper range. We can do a normal search.
      reset = 0;

    } else if (test_val == 0) {
      // the generated value is 0, another special case
      // change the limb value depending of the number of zeroes we get
      while (!test_val && curr_limb >= min_limb) {
        curr_limb--;
        test_val = UniGet64bits_Fast();
      }

      // it's lower than all array values, therefore index 0 is returned
      if (curr_limb < min_limb) {
        return 0;
      }

      // we can do a casual search now
      reset = 0;

      curr_low = interval[curr_limb][0];
      curr_high = interval[curr_limb][1];
      curr_pos = (curr_low + curr_high) >> 1;
    } else {
      // the non-critical case, generated value is not zero and not equal to the
      // max, and no need to generate a new_value to test.
      reset = 0;

      curr_low = interval[curr_limb][0];
      curr_high = interval[curr_limb][1];
      curr_pos = (curr_low + curr_high) >> 1;
    }
  }

  // CASUAL SEARCH PART

  // start searching by dichotomy
  while ((curr_high - curr_low) > 1) {

    // check which part of the array we have to navigate
    tmp_limb = cst_val_tab[curr_pos].tab[curr_limb - 1];

    // ALTERNATIVE CODE

    if (test_val > tmp_limb) {
      /* value bigger */
      curr_low = curr_pos;
      curr_pos = (curr_pos + curr_high + 1) / 2;
    } else if (test_val != tmp_limb) {
      /* case not bigger, not equal --> smaller*/
      curr_high = curr_pos;
      curr_pos = (curr_low + curr_pos + 1) / 2;
    } else {
      // case equality
      if (curr_limb > 1) {
        curr_limb--;
        test_val = UniGet64bits_Fast();
        break;
      } else {
        // we care about strictly inferior only, this is an equality case
        return curr_pos + 1;
      }
    }

  } // end search

  if (cst_val_tab[curr_high].tab[curr_limb - 1] < test_val) {
    // we are bigger than the biggest value of our current interval
    // this is possible because we ensure the random value is strictly smaller
    // than the biggest value of the array
    return curr_high + 1;
  } else if (cst_val_tab[curr_low].tab[curr_limb - 1] < test_val) {
    // we are bigger than the smallest value of interval but not the biggest
    return curr_high;
  }
  // we are smaller than the smallest value of our interval
  return curr_low;
}

#endif
