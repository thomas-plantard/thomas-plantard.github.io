/* Corresponding array structure for dichotomy search and zero distribution */
#include <stdint.h>
#include <stdlib.h>

#ifndef _BIG_NUM_STRUCT_H_
#define _BIG_NUM_STRUCT_H_

typedef struct {
  const int const size;
  const uint64_t *const tab;
} cst_ext_uint;

typedef struct {
  int size;
  uint64_t *tab;
} ext_uint;

#endif

#ifndef _DEF_GUARD_sum_array_
#define _DEF_GUARD_sum_array_

const uint64_t const _tab_sum_array_0_[] = { 0x0000000000000001, 0x00000000000011c0 };
const uint64_t const _tab_sum_array_1_[] = { 0x0000000000000002, 0x0000000000550180 };
const uint64_t const _tab_sum_array_2_[] = { 0x0000000000000003, 0x0000000083f79250 };
const uint64_t const _tab_sum_array_3_[] = { 0x0000000000000004, 0x0000006395a5e430 };
const uint64_t const _tab_sum_array_4_[] = { 0x0000000000000005, 0x00002bd19c4a889c };
const uint64_t const _tab_sum_array_5_[] = { 0x0000000000000006, 0x000c7cd24b61f670 };
const uint64_t const _tab_sum_array_6_[] = { 0x0000000000000007, 0x0277f959445adcd1 };
const uint64_t const _tab_sum_array_7_[] = { 0x0000000000000008, 0x5af77a58435733d1 };
const uint64_t const _tab_sum_array_8_[] = { 0x0000000000000009, 0xe231cdcc976251c1, 0x0000000000000009 };
const uint64_t const _tab_sum_array_9_[] = { 0x000000000000000a, 0x5d429680d8c18171, 0x00000000000000d5 };
const uint64_t const _tab_sum_array_10_[] = { 0x000000000000000b, 0xf699cfd4acc22485, 0x0000000000000e46 };
const uint64_t const _tab_sum_array_11_[] = { 0x000000000000000c, 0xdbcadd919a9c48ad, 0x000000000000c599 };
const uint64_t const _tab_sum_array_12_[] = { 0x000000000000000d, 0x438fccff8c07f168, 0x000000000008c2f4 };
const uint64_t const _tab_sum_array_13_[] = { 0x000000000000000e, 0x0b0309a8d847bcd1, 0x000000000052999d };
const uint64_t const _tab_sum_array_14_[] = { 0x400000000000000f, 0x5b0b4725920208bd, 0x00000000028dcb2f };
const uint64_t const _tab_sum_array_15_[] = { 0xc000000000000010, 0xee745054718ff8c4, 0x0000000011219795 };
const uint64_t const _tab_sum_array_16_[] = { 0xfc00000000000011, 0x8e63710a80700ff5, 0x000000006230dc6c };
const uint64_t const _tab_sum_array_17_[] = { 0x3800000000000012, 0x977c764fd65f8d86, 0x00000001e46a8dd4 };
const uint64_t const _tab_sum_array_18_[] = { 0xfd00000000000013, 0xa365d5b0529bc0b5, 0x000000081689a2a5 };
const uint64_t const _tab_sum_array_19_[] = { 0x2300000000000014, 0x0bc1cab6c3ddba32, 0x0000001e21ca68ab };
const uint64_t const _tab_sum_array_20_[] = { 0x77c0000000000015, 0x1378216ab6acc173, 0x0000006263b8760e };
const uint64_t const _tab_sum_array_21_[] = { 0x7100000000000016, 0x88c05878600177fd, 0x0000011b11ab5d52 };
const uint64_t const _tab_sum_array_22_[] = { 0x6790000000000017, 0x40e760a6b34420f9, 0x000002d13a012979 };
const uint64_t const _tab_sum_array_23_[] = { 0xe490000000000018, 0xc138d5e5fcda603e, 0x00000663a4716f5a };
const uint64_t const _tab_sum_array_24_[] = { 0x1000000000000019, 0xb7e344218783a636, 0x00000cf6edece92a };
const uint64_t const _tab_sum_array_25_[] = { 0x17b000000000001a, 0xb615d1bf18de1101, 0x000017aacd81e75d };
const uint64_t const _tab_sum_array_26_[] = { 0x3b6400000000001b, 0xb8689427480cc892, 0x0000271a8b0ef389 };
const uint64_t const _tab_sum_array_27_[] = { 0x22ac00000000001c, 0xf9b0aef06804e050, 0x00003ade7192ca3b };
const uint64_t const _tab_sum_array_28_[] = { 0x582f00000000001d, 0x408c64c40e7775ab, 0x0000515f6089aec1 };
const uint64_t const _tab_sum_array_29_[] = { 0x4b5800000000001e, 0x7f8e71d86b4af622, 0x0000682fc58e92e5 };
const uint64_t const _tab_sum_array_30_[] = { 0xb9d240000000001f, 0xae0a61504236b3de, 0x00007cce1b595351 };
const uint64_t const _tab_sum_array_31_[] = { 0xd0da000000000020, 0x05137d458c70affa, 0x00008d6ed426200c };
const uint64_t const _tab_sum_array_32_[] = { 0x22e44f0000000021, 0x4eaa69c51bb6cf5c, 0x0000996864df6f1f };
const uint64_t const _tab_sum_array_33_[] = { 0x93eb660000000022, 0xa9d3dc14744264b1, 0x0000a11d10f2497a };
const uint64_t const _tab_sum_array_34_[] = { 0x6f126f4000000023, 0x5aee2c9179e84da1, 0x0000a58bc461cf78 };
const uint64_t const _tab_sum_array_35_[] = { 0xee6856c000000024, 0xda954ea5e3365065, 0x0000a7d353dcfe6f };
const uint64_t const _tab_sum_array_36_[] = { 0xca0498f000000025, 0x47ecd3d835d85c3d, 0x0000a8dfab45349c };
const uint64_t const _tab_sum_array_37_[] = { 0xfcf85cc000000026, 0x206432a86fd96dda, 0x0000a94dfba13508 };
const uint64_t const _tab_sum_array_38_[] = { 0x81707fa400000027, 0x269858dc95be5b31, 0x0000a9768363a83b };
const uint64_t const _tab_sum_array_39_[] = { 0x97e952a400000028, 0x22112cf2f3935661, 0x0000a983d0c44c12 };
const uint64_t const _tab_sum_array_40_[] = { 0xdf6e989400000029, 0xc62034c41e85541c, 0x0000a987b68038a3 };
const uint64_t const _tab_sum_array_41_[] = { 0x5274e1440000002a, 0x87be72926adbc220, 0x0000a988bb3b9692 };
const uint64_t const _tab_sum_array_42_[] = { 0x091795580000002b, 0xe44fa8cb4f6a1208, 0x0000a988f7f0b602 };
const uint64_t const _tab_sum_array_43_[] = { 0xbb1c11400000002c, 0x271e2f6d8f0154eb, 0x0000a9890484a5cb };
const uint64_t const _tab_sum_array_44_[] = { 0x2371d69b0000002d, 0x4f57fc939290f599, 0x0000a98906d568a0 };
const uint64_t const _tab_sum_array_45_[] = { 0x125902b40000002e, 0x87a0be998843be36, 0x0000a9890736329c };
const uint64_t const _tab_sum_array_46_[] = { 0x497b7d884000002f, 0xbf5d1c7ac74ef616, 0x0000a98907443012 };
const uint64_t const _tab_sum_array_47_[] = { 0x149b2046c0000030, 0xf7800d3af00995bb, 0x0000a9890745f947 };
const uint64_t const _tab_sum_array_48_[] = { 0xc4eb09993c000031, 0x93da9ed5c598e988, 0x0000a98907462cb2 };
const uint64_t const _tab_sum_array_49_[] = { 0x069b93caf8000032, 0xb89d23eaeac88197, 0x0000a989074631c6 };
const uint64_t const _tab_sum_array_50_[] = { 0xe1d27290ed000033, 0x253449067f03e337, 0x0000a98907463237 };
const uint64_t const _tab_sum_array_51_[] = { 0x4875ab2323000034, 0x9fafa8e130ffdeff, 0x0000a9890746323f };
const uint64_t const _tab_sum_array_52_[] = { 0x064f9792e3c00035, 0x2dd6abf3ed3ca2b7, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_53_[] = { 0xcd6f3f85e5000036, 0x35e28a50c2c27d7d, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_54_[] = { 0xefb02f5818900037, 0x3646c26e03f7ef9c, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_55_[] = { 0xd88257e5d1900038, 0x364aeca86a6b3231, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_56_[] = { 0x933db85d57000039, 0x364b123c84e2fcd7, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_57_[] = { 0x1c6a74e9c9b0003a, 0x364b1359b042afaf, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_58_[] = { 0x238197cad7e4003b, 0x364b1360baf1d2bc, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_59_[] = { 0xbfda9429abec003c, 0x364b1360df9c0092, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_60_[] = { 0xbf4a6c68a6af003d, 0x364b1360e0372802, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_61_[] = { 0x4db37763eee8003e, 0x364b1360e039351f, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_62_[] = { 0x25e32793f542403f, 0x364b1360e0393a91, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_63_[] = { 0x35d34773d4cd2040, 0x364b1360e0393a9c, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_64_[] = { 0x4680f860ef31da01, 0x364b1360e0393a9c, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_65_[] = { 0x4692e290798279c2, 0x364b1360e0393a9c, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_66_[] = { 0x4692ef8749d23093, 0x364b1360e0393a9c, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_67_[] = { 0x4692ef8d1daf4474, 0x364b1360e0393a9c, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_68_[] = { 0x4692ef8d1f1d8e61, 0x364b1360e0393a9c, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_69_[] = { 0x4692ef8d1f1db4a8, 0x364b1360e0393a9c, 0x0000a98907463240 };
const uint64_t const _tab_sum_array_70_[] = { 0x4692ef8d1f1db4a9, 0x364b1360e0393a9c, 0x0000a98907463240 };

const size_t size_sum_array = 71;
cst_ext_uint sum_array[71] = {
{ .size = 2, .tab = _tab_sum_array_0_},
{ .size = 2, .tab = _tab_sum_array_1_},
{ .size = 2, .tab = _tab_sum_array_2_},
{ .size = 2, .tab = _tab_sum_array_3_},
{ .size = 2, .tab = _tab_sum_array_4_},
{ .size = 2, .tab = _tab_sum_array_5_},
{ .size = 2, .tab = _tab_sum_array_6_},
{ .size = 2, .tab = _tab_sum_array_7_},
{ .size = 3, .tab = _tab_sum_array_8_},
{ .size = 3, .tab = _tab_sum_array_9_},
{ .size = 3, .tab = _tab_sum_array_10_},
{ .size = 3, .tab = _tab_sum_array_11_},
{ .size = 3, .tab = _tab_sum_array_12_},
{ .size = 3, .tab = _tab_sum_array_13_},
{ .size = 3, .tab = _tab_sum_array_14_},
{ .size = 3, .tab = _tab_sum_array_15_},
{ .size = 3, .tab = _tab_sum_array_16_},
{ .size = 3, .tab = _tab_sum_array_17_},
{ .size = 3, .tab = _tab_sum_array_18_},
{ .size = 3, .tab = _tab_sum_array_19_},
{ .size = 3, .tab = _tab_sum_array_20_},
{ .size = 3, .tab = _tab_sum_array_21_},
{ .size = 3, .tab = _tab_sum_array_22_},
{ .size = 3, .tab = _tab_sum_array_23_},
{ .size = 3, .tab = _tab_sum_array_24_},
{ .size = 3, .tab = _tab_sum_array_25_},
{ .size = 3, .tab = _tab_sum_array_26_},
{ .size = 3, .tab = _tab_sum_array_27_},
{ .size = 3, .tab = _tab_sum_array_28_},
{ .size = 3, .tab = _tab_sum_array_29_},
{ .size = 3, .tab = _tab_sum_array_30_},
{ .size = 3, .tab = _tab_sum_array_31_},
{ .size = 3, .tab = _tab_sum_array_32_},
{ .size = 3, .tab = _tab_sum_array_33_},
{ .size = 3, .tab = _tab_sum_array_34_},
{ .size = 3, .tab = _tab_sum_array_35_},
{ .size = 3, .tab = _tab_sum_array_36_},
{ .size = 3, .tab = _tab_sum_array_37_},
{ .size = 3, .tab = _tab_sum_array_38_},
{ .size = 3, .tab = _tab_sum_array_39_},
{ .size = 3, .tab = _tab_sum_array_40_},
{ .size = 3, .tab = _tab_sum_array_41_},
{ .size = 3, .tab = _tab_sum_array_42_},
{ .size = 3, .tab = _tab_sum_array_43_},
{ .size = 3, .tab = _tab_sum_array_44_},
{ .size = 3, .tab = _tab_sum_array_45_},
{ .size = 3, .tab = _tab_sum_array_46_},
{ .size = 3, .tab = _tab_sum_array_47_},
{ .size = 3, .tab = _tab_sum_array_48_},
{ .size = 3, .tab = _tab_sum_array_49_},
{ .size = 3, .tab = _tab_sum_array_50_},
{ .size = 3, .tab = _tab_sum_array_51_},
{ .size = 3, .tab = _tab_sum_array_52_},
{ .size = 3, .tab = _tab_sum_array_53_},
{ .size = 3, .tab = _tab_sum_array_54_},
{ .size = 3, .tab = _tab_sum_array_55_},
{ .size = 3, .tab = _tab_sum_array_56_},
{ .size = 3, .tab = _tab_sum_array_57_},
{ .size = 3, .tab = _tab_sum_array_58_},
{ .size = 3, .tab = _tab_sum_array_59_},
{ .size = 3, .tab = _tab_sum_array_60_},
{ .size = 3, .tab = _tab_sum_array_61_},
{ .size = 3, .tab = _tab_sum_array_62_},
{ .size = 3, .tab = _tab_sum_array_63_},
{ .size = 3, .tab = _tab_sum_array_64_},
{ .size = 3, .tab = _tab_sum_array_65_},
{ .size = 3, .tab = _tab_sum_array_66_},
{ .size = 3, .tab = _tab_sum_array_67_},
{ .size = 3, .tab = _tab_sum_array_68_},
{ .size = 3, .tab = _tab_sum_array_69_},
{ .size = 3, .tab = _tab_sum_array_70_}
};

const int const sum_array_limb_interval[4][2] ={
{0,-1},
{-1,-1},
{0,7},
{8,70}
};

#endif
