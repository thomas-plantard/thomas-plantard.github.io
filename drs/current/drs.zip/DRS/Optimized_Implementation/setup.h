#ifndef SETUP_H
#define SETUP_H

#include "crypto_struct.h"
#include "gmp_pseudo_struct.h"
#include <math.h>

// Those are pre-loaded constants that affect the secret key generation
// #include "sum_array.h"
#define _SUM_ARRAY_ (sum_array)
#define _SIZE_SUM_ARRAY_ (size_sum_array)
#define _INTERVAL_ARRAY_ (sum_array_limb_interval)

// THE FOLLOWING TWO MACROS ARE FOR THE PUBLIC KEY

#define _PK_USE_LOADED_SIGNS_()                                                \
  do {                                                                         \
    /* sign precomputation */                                                  \
    /*   array_index[0] and index[0] for negatives */                          \
    /*   array_index[1] and index[1] for positives */                          \
    index[0] = 0;                                                              \
    index[1] = 0;                                                              \
                                                                               \
    for (size_t i = 0; i < _DIM_ - 1;) {                                       \
      for (; signs_pos_bit < 64 && i < _DIM_ - 1; signs_pos_bit++, i += 2) {   \
        /* increment index for either positive or negative */                  \
        /* METHOD 1 */                                                         \
        /*                                                                     \
        size_t sgn = signs[signs_pos_array] & 1;                               \
        signs[signs_pos_array] >>= 1;                                          \
        array_index[sgn][index[sgn]] = i;                                      \
        index[sgn]++;                                                          \
        */                                                                     \
                                                                               \
        /* METHOD 2 */                                                         \
        size_t sgn = signs[signs_pos_array] >> 63;                             \
        signs[signs_pos_array] <<= 1;                                          \
        array_index[sgn][index[sgn]] = i;                                      \
        index[sgn]++;                                                          \
      }                                                                        \
      /* switch to next pack of 64_bit if needed */                            \
      signs_pos_bit &= 63;                                                     \
      signs_pos_array += (!signs_pos_bit);                                     \
    }                                                                          \
  } while (0)

#define _PK_VECTOR_OPS_(TYPE_CAST, VEC_1, VEC_2)                               \
  do {                                                                         \
    /* do the negative incrementations */                                      \
    for (size_t i = 0; i < index[0]; i++) {                                    \
      VEC_1 = (TYPE_CAST *)(A[array_index[0][i]]);                             \
      VEC_2 = (TYPE_CAST *)(A[array_index[0][i] + 1]);                         \
      for (size_t j = 0; j < _DIM_; j++) {                                     \
        VEC_1[j] = VEC_1[j] - VEC_2[j];                                        \
        VEC_2[j] = VEC_2[j] - VEC_1[j];                                        \
      }                                                                        \
    }                                                                          \
    /* do the positive incrementations */                                      \
    for (size_t i = 0; i < index[1]; i++) {                                    \
      VEC_1 = (TYPE_CAST *)(A[array_index[1][i]]);                             \
      VEC_2 = (TYPE_CAST *)(A[array_index[1][i] + 1]);                         \
      for (size_t j = 0; j < _DIM_; j++) {                                     \
        VEC_1[j] = VEC_1[j] + VEC_2[j];                                        \
        VEC_2[j] = VEC_2[j] + VEC_1[j];                                        \
      }                                                                        \
    }                                                                          \
  } while (0)

// Constructs the matrix public key
void public_key_construct(public_key *pk, unsigned char *seed) {
  // use for precomputation of sign
  uint16_t index[2];
  uint16_t array_index[2][_DIM_ / 2];

  int64_t **A = pk->dat;
  int64_t *A1_64, *A2_64;
  int32_t *A1_32, *A2_32;
  // initialize the randomness with the given seed
  UniRandSeed(seed);
  // Now creates the final public key matrix
  // computes the number of rounds we can do with 32-bits vectors
  unsigned int nb_rounds_32 = 0;
  unsigned int max_v = 3 * _D_BOUND_;
  for (; max_v < ((uint32_t)1 << 31); max_v *= 3) {
    nb_rounds_32++;
  }

  // precompute all signs
  const size_t nb_signs_64 = (((NB_ROUNDS * _DIM_ / 2) - 1) / 64) + 1;
  uint64_t signs[nb_signs_64];
  size_t signs_pos_array = 0;
  size_t signs_pos_bit = 0;
  // load it all
  seedexpander(_UniRand_, (unsigned char *)(signs), nb_signs_64 * 8);

  // rounds on 32 bits
  for (size_t k = 0; k < nb_rounds_32; k++) {
    // call the random generator
    _UniIncreasingRandom_Permut_2((int64_t *)A, _DIM_, _BITS_DIM);

    // use the loaded signs (see macro)
    _PK_USE_LOADED_SIGNS_();

    // reduce
    _PK_VECTOR_OPS_(int32_t, A1_32, A2_32);
  }

  // convert the vectors to 64-bits integers vectors
  for (unsigned int i = 0; i < _DIM_; i++) {
    A1_64 = (int64_t *)A[i];
    A1_32 = (int32_t *)A[i];
    for (int j = _DIM_ - 1; j >= 0; j--) {
      A1_64[j] = (int64_t)(A1_32[j]);
    }
  }

  // rounds on 64-bits
  for (size_t k = 0; k < NB_ROUNDS - nb_rounds_32; k++) {
    // call the random generator
    _UniIncreasingRandom_Permut_2((int64_t *)A, _DIM_, _BITS_DIM);

    // use the loaded signs (see macro)
    _PK_USE_LOADED_SIGNS_();

    _PK_VECTOR_OPS_(int64_t, A1_64, A2_64);
  }

  // call the random generator one last time
  _UniIncreasingRandom_Permut_2((int64_t *)A, _DIM_, _BITS_DIM);
}

// transpose the matrix (useful when multiplying by row vectors)
void transpose_key(int64_t **mat) {
  int64_t tmp;
  for (unsigned int i = 0; i < _DIM_; i++) {
    for (unsigned int j = i + 1; j < _DIM_; j++) {
      tmp = mat[i][j];
      mat[i][j] = mat[j][i];
      mat[j][i] = tmp;
    }
  }
}

// permut zero elements between start and size with the ones between 0 and start
void _char_combination_permut_bounded(unsigned char *array, const size_t start,
                                      const size_t size,
                                      const size_t nb_bits_size) {
  size_t nb_zeroes = size - start;
  memset(array,1,size);
  while (nb_zeroes) {
    int index = UniRandExtract(nb_bits_size);
    if (index >= size) {continue;}
    if (array[index]) {array[index] = 0;nb_zeroes--;}
  }
}

void random_combination_generation(int32_t *vec, const size_t nb_non_zeroes) {
  // this only works if dim is inferior to _D_BOUND_
  unsigned char TAB[_D_BOUND_ - _DELTA_] = {0};

  // initialize array with dim 1
  for (size_t i = 0; i < nb_non_zeroes; i++) {
    TAB[i] = 1;
  }

  // permute all those elements
  _char_combination_permut_bounded(TAB, nb_non_zeroes, _D_BOUND_ - _DELTA_,
                                   _BITS_D_BD_DELTA);

  //check that the number of non_zero values are correct
  // size_t check = 0;
  // for (size_t i = 0; i < _D_BOUND_ - _DELTA_; i++) {
  //   check += TAB[i];
  // }
  // if (check != nb_non_zeroes) {fprintf(stderr, "not the same non_zeroes\n");}

  // once all values dim, fill vec.
  size_t index = nb_non_zeroes - 1;
  // size_t low;
  size_t big = _D_BOUND_ - _DELTA_ - 1, low;

  // search for the first "big" value
  while (!TAB[big]) {
    big--;
  }

  low = big - 1;
  while (index) {
    while (!TAB[low] && index) {
      low--;
    }
    vec[index] = big - low;
    index--;
    big = low;
    low = big - 1;
  }
  vec[0]=big + 1;
}

void secret_key_setup(secret_key *sk, unsigned char *init_seed) {
  // use another temporary seed for the secret key
  AES_XOF_struct ctx[1];
  unsigned char sk_seed[32];
  unsigned char pk_seed[32];
  seedexpander_init(ctx, init_seed, _UniversalDiversifier_, UINT32_MAX);
  seedexpander(ctx, sk_seed, 32);
  seedexpander(ctx, pk_seed, 32);
  // this seed will be used for the generation of the public key and signing
  for (size_t i = 0; i < 32; i++) {
    sk->RandSeed[i] = pk_seed[i];
  }
  // the other
  UniRandSeed(sk_seed);

  // storage of the vector of noise, with no diagonal coefficent
  int32_t* rdm_vector;
  int32_t nb_zeroes_tab[_DIM_];
  size_t nb_total_non_zeroes = 0;
  // precompute the number of non zeroes
  for (size_t i = 0; i < _DIM_; i++) {
    nb_zeroes_tab[i] =
        rdm_from_sum_dist(_SUM_ARRAY_, _INTERVAL_ARRAY_, _SIZE_SUM_ARRAY_);
    nb_total_non_zeroes += (_DIM_ - 1) - (nb_zeroes_tab[i]);
  }
  // precompute all signs
  const size_t nb_max_signs_32 = (((_DIM_ * (_DIM_ - 1)) - 1) / 32) + 1;
  int32_t signs[nb_max_signs_32];
  size_t signs_pos_array = 0;
  size_t signs_pos_bit = 0;
  seedexpander(_UniRand_, (unsigned char *)(signs),
               (((nb_total_non_zeroes - 1) / 32) + 1) * 4);

  // start matrix loop
  for (size_t i = 0; i < _DIM_; i++) {
    // get a random number the number of zeroes
    // fill rdm_vector with random values
    rdm_vector = sk->A.dat[i];

    random_combination_generation(rdm_vector,
                                  _SIZE_SUM_ARRAY_ - nb_zeroes_tab[i]);

    // generate the signs, permutation and swaps
    // check the number of 64-bits packs we will have to have
    size_t s = 0;
    for (; s < _DIM_ - nb_zeroes_tab[i];) {

      for (; signs_pos_bit < 32 && s < _DIM_ - nb_zeroes_tab[i];
           signs_pos_bit++, s++) {
        // this is either 0 or -1
        int32_t sgn = signs[signs_pos_array] >> 31;
        signs[signs_pos_array] <<= 1;
        // use sgn to reduce
        rdm_vector[s] = (rdm_vector[s] ^ sgn) - sgn;
      }
      // switch to next pack of 32_bit
      signs_pos_bit &= 31;
      signs_pos_array += (!signs_pos_bit);
    }

    // Permut the result!
    _UniIncreasingRandom_Permut_2_32(rdm_vector, _DIM_, _BITS_DIM);

    // Adds the diagonal coefficient
    rdm_vector[i] += _D_BOUND_;
  }
  // end matrix loop
}

// given sk, setup pk
void key_setup(public_key *pk, secret_key *sk) {
  // transfer values
  for (unsigned int i = 0; i < _DIM_; i++) {
    // PASS AS 32-bits. Will update later
    for (size_t j = 0; j < _DIM_; j++) {
      ((int32_t*)pk->dat[i])[j] = sk->A.dat[i][j];
    }
  }
  // fill
  public_key_construct(pk, sk->RandSeed);
  transpose_key(pk->dat);
  // compute the max norm of the matrix (the matrix is already transposed)
  uint64_t m_norm[_DIM_];
  for (size_t i = 0; i < _DIM_; i++) {
    m_norm[i] = 0;
    for (size_t j = 0; j < _DIM_; j++) {
      m_norm[i] += _ABS64_(pk->dat[i][j]);
    }
  }
  // get the specific divisor for the verification function
  pk->log_reduc = m_norm[0];
  for (size_t i = 1; i < _DIM_; i++) {
    pk->log_reduc |= m_norm[i];
  }
  pk->log_reduc = (((uint64_t)1) << (62 - Log2_64(pk->log_reduc)));
}

// given a seed, set up both keys
void setup(secret_key *sk, public_key *pk, unsigned char *seed) {
  secret_key_setup(sk, seed);
  key_setup(pk, sk);
}

#endif // SETUP_H0
