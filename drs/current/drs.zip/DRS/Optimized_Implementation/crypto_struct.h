#ifndef CRYPTO_STRUCT_H
#define CRYPTO_STRUCT_H

#include "api.h"

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define _ABS64_(c) (((c >> 63) ^ c) - (c >> 63))

const int8_t DeBruijn64[64] = {
    63, 0,  58, 1,  59, 47, 53, 2,  60, 39, 48, 27, 54, 33, 42, 3,
    61, 51, 37, 40, 49, 18, 28, 20, 55, 30, 34, 11, 43, 14, 22, 4,
    62, 57, 46, 52, 38, 26, 32, 41, 50, 36, 17, 19, 29, 10, 13, 21,
    56, 45, 25, 31, 35, 16, 9,  12, 44, 24, 15, 8,  23, 7,  6,  5};

int8_t Log2_64(uint64_t x) {
  x |= (x >> 1);
  x |= (x >> 2);
  x |= (x >> 4);
  x |= (x >> 8);
  x |= (x >> 16);
  x |= (x >> 32);
  return DeBruijn64[((uint64_t)((x - (x >> 1)) * 0x07EDD5E59A4E28C2)) >> 58];
}

typedef struct {
  // contains the diagonal dominant matrix
  int32_t **dat;
} reduction_matrix;
typedef struct {
  // contains the reduced message
  int64_t *dat;
  // and contains the membership test vector
  int64_t *k;
} signature;
typedef struct {
  // just a hashed message vector
  int64_t *dat;
} message;
typedef struct {
  int64_t **dat;
  // determines the divisor used for the verification (basically max_norm of dat
  // - log_limit_m)
  int64_t log_reduc;
} public_key;
typedef struct {
  reduction_matrix A;
  // this is the same as 32 chars
  unsigned char RandSeed[SEED_SIZE];
} secret_key;

// initialize memory for the message structure
void init_message(message **m) {
  // allocate structure memory
  *m = (message *)malloc(sizeof(message));
  if (*m == NULL) {
    printf("Message allocation failed\n");
    exit(EXIT_FAILURE);
  }
  // allocate hashed message vector memory
  (*m)->dat = (int64_t *)calloc(_DIM_, sizeof(int64_t));
  if ((*m)->dat == NULL) {
    printf("Message allocation failed\n");
    exit(EXIT_FAILURE);
  }
}

// initialize memory for the public key structure
void init_public_key(public_key **pk) {
  // allocate structure memory
  *pk = (public_key *)malloc(sizeof(public_key));
  if (*pk == NULL) {
    printf("Public key allocation failed\n");
    exit(EXIT_FAILURE);
  }
  // allocate matrix memory
  (*pk)->dat = (int64_t **)malloc(_DIM_ * sizeof(int64_t *));
  if ((*pk)->dat == NULL) {
    printf("Public key allocation failed\n");
    exit(EXIT_FAILURE);
  }
  // allocate vector memory
  for (unsigned int i = 0; i < _DIM_; i++) {
    (*pk)->dat[i] = (int64_t *)calloc(_DIM_, sizeof(int64_t));
    if ((*pk)->dat[i] == NULL) {
      printf("Public key allocation failed\n");
      exit(EXIT_FAILURE);
    }
  }
}

// initialize memory for the secret key structure
void init_secret_key(secret_key **sk) {
  // allocate structure memory
  *sk = (secret_key *)malloc(sizeof(secret_key));
  if (*sk == NULL) {
    printf("Secret key allocation failed\n");
    exit(EXIT_FAILURE);
  }
  // allocate matrix memory
  (*sk)->A.dat = (int32_t **)malloc(_DIM_ * sizeof(int32_t *));
  if ((*sk)->A.dat == NULL) {
    printf("Secret key allocation failed\n");
    exit(EXIT_FAILURE);
  }
  // allocate vector memory
  int32_t *tmp = (int32_t *)calloc(_DIM_ * _DIM_, sizeof(int32_t));
  if (tmp == NULL) {
    printf("Secret key allocation failed\n");
    exit(EXIT_FAILURE);
  }
  for (unsigned int i = 0; i < _DIM_; i++) {
    (*sk)->A.dat[i] = tmp + (i * _DIM_);
  }
}

// initialize memory for the signature structure
void init_signature(signature **s) {
  // allocate structure memory
  *s = (signature *)malloc(sizeof(signature));
  if (*s == NULL) {
    printf("Signature allocation failed\n");
    exit(EXIT_FAILURE);
  }
  // allocate reduced message vector memory
  (*s)->dat = (int64_t *)calloc(_DIM_, sizeof(int64_t));
  if ((*s)->dat == NULL) {
    printf("Signature allocation failed\n");
    exit(EXIT_FAILURE);
  }
  // allocate membership vector memory
  (*s)->k = (int64_t *)calloc(_DIM_, sizeof(int64_t));
  if ((*s)->k == NULL) {
    printf("Signature allocation failed\n");
    exit(EXIT_FAILURE);
  }
}

// free memory for the message structure
void free_message(message *m) {
  free(m->dat);
  free(m);
}
// free memory for the signature structure
void free_signature(signature *s) {
  free(s->dat);
  free(s->k);
  free(s);
}
// free memory for the secret key structure
void free_secret_key(secret_key *sk) {
  free(sk->A.dat[0]);
  free(sk->A.dat);
  free(sk);
}
// free memory for the public key structure
void free_public_key(public_key *pk) {
  for (unsigned int i = 0; i < _DIM_; i++) {
    free(pk->dat[i]);
  }
  free(pk->dat);
  free(pk);
}

#endif // CRYPTO_STRUCT_H
