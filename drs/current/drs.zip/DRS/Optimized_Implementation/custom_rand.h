#ifndef _CUSTOM_RAND_H_
#define _CUSTOM_RAND_H_

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "crypto_struct.h"
#include "rng.h"

/**************************************/
/*                                    */
/*        WITH UNIVERSAL SEEDS        */
/*                                    */
/**************************************/

// array of values, all values lower than 16 bits (assuming _DIM_ is lower than
// 16 bits)
// at the end, values[x] must be a random value strictly inferior or equal to x

#define _PERM_INT_SIZE_ size_t

AES_XOF_struct _UniRand_[1];
// this is clearly an arbitrary initializer: you can change those as you see fit
// unsigned char _UniversalDiversifier_[8] = {1, 1, 1, 1, 1, 1, 1, 1};
unsigned char _UniversalDiversifier_[8] = {0, 0, 0, 0, 0, 0, 0, 0};

// defines the number of 64_bits packages we store and generate at a time (with
// seedexpander)
#define _UniPow2ShiftRandStore_ (2)
#define _UniNb64_ (1 << _UniPow2ShiftRandStore_)
// use x & _UniNb64MaskMod_ to get a mod
#define _UniNb64MaskMod_ (_UniNb64_ - 1)
#define _Unixlen_ (8 * _UniNb64_)

// This is our global storage or randomly generated bits that our functions will
// tap into
typedef union {
  unsigned char C[_Unixlen_];
  uint64_t I[_UniNb64_];
} _UniRandStruct_;
_UniRandStruct_ _UniRandStore_;

// helps us track how much bits/uint64_t we have have used so far
int _UniPosNb64_ = 0;
int _UniPosBit64_ = 0;

// Using NIST's functions

void UniRandSeed(unsigned char *seed) {
  seedexpander_init(_UniRand_, seed, _UniversalDiversifier_, UINT32_MAX);
  // call the first random series
  seedexpander(_UniRand_, (_UniRandStore_.C), _Unixlen_);
  // sets our initial position
  _UniPosNb64_ = 0;
  _UniPosBit64_ = 0;
}

void refresh_rdm() { seedexpander(_UniRand_, (_UniRandStore_.C), _Unixlen_); }

// IF WE WANT TO AVOID NIST RANDOMS FOR TESTS, NEXT TWO FUNCTIONS CAN BE SUBSITUTED BY
// size_t UniGet64bits_Fast() {return ((uint64_t)rand() << 33) | ((uint64_t)rand() << 1) | ((uint64_t)rand() & 1);}
// size_t UniRandExtract(size_t nb_bits) {return (UniGet64bits_Fast()) >> (64 - nb_bits);}

// This function extracts the number of bits needed.
// don't call this with a parameter 0 or over 64
size_t UniRandExtract(size_t nb_bits) {
  size_t res;
  uint64_t mask_bit = ((uint64_t)-1) >> (64 - nb_bits);
  // did we use all 64bits integers of our big char array?

  if (_UniPosBit64_ + nb_bits <= 64) {
    res = _UniRandStore_.I[_UniPosNb64_] & mask_bit;
    _UniRandStore_.I[_UniPosNb64_] >>= nb_bits;
    _UniPosBit64_ += nb_bits;
    return res;
  } else {
    // we will use all leftovers before changing part
    int extra_shift = 64 - _UniPosBit64_ ;
    res = _UniRandStore_.I[_UniPosNb64_];
    // change part
    _UniPosNb64_++;
    _UniPosNb64_ &= _UniNb64MaskMod_;
    if (!_UniPosNb64_) {refresh_rdm();}
    // get what we missed
    res |= (_UniRandStore_.I[_UniPosNb64_] << (extra_shift)) & mask_bit;
    _UniRandStore_.I[_UniPosNb64_] >>= (nb_bits - extra_shift);
    _UniPosBit64_ = nb_bits - extra_shift;
    return res;
  }
}

// Get a quick pack of 64-bits. Bits are not taken in order.
// (take the next cell, replace its value by the current cell and increment cell
// count)
size_t UniGet64bits_Fast() {
  uint64_t leftover = _UniRandStore_.I[_UniPosNb64_]; // get leftover
  _UniPosNb64_++; // go to next cell
  _UniPosNb64_ &= _UniNb64MaskMod_; // use modulo
  if (!_UniPosNb64_) {refresh_rdm();} // refresh if necessary
  size_t res = _UniRandStore_.I[_UniPosNb64_]; // take the full cell
  _UniRandStore_.I[_UniPosNb64_] = leftover; // put the leftover
  return res;
}

// apply the permutation to an array of a certain size, also gives a number of
// bits to start with (avoid computations in loops)
void _UniIncreasingRandom_Permut_2(int64_t *array, const size_t size,
                                   const size_t nb_bits_start) {
  size_t tmp_rdm;
  int64_t tmp;

  // initial index
  size_t i = 0;
  size_t range = size - 1;

  int64_t nb_bits = nb_bits_start;
  size_t next_val = 1 << (nb_bits_start - 1);

  // while we haven't permuted everything is not negative
  while (i < size - 1) {
    do {
      tmp_rdm = UniRandExtract(nb_bits);
    } while (tmp_rdm > range);

    // swap
    tmp = array[i];
    array[i] = array[i + tmp_rdm];
    array[i + tmp_rdm] = tmp;

    // decrement
    i++;

    if (next_val == range) {
      next_val = next_val >> 1;
      nb_bits--;
    }
    range--;
  }
}

void _UniIncreasingRandom_Permut_2_32(int32_t *array, const size_t size,
                                      const size_t nb_bits_start) {
  size_t tmp_rdm;
  int32_t tmp;

  // initial index
  size_t i = 0;
  size_t range = size - 1;

  int64_t nb_bits = nb_bits_start;
  size_t next_val = 1 << (nb_bits_start - 1);

  // while we haven't permuted everything is not negative
  while (i < size - 1) {
    do {
      tmp_rdm = UniRandExtract(nb_bits);
    } while (tmp_rdm > range);

    // swap
    tmp = array[i];
    array[i] = array[i + tmp_rdm];
    array[i + tmp_rdm] = tmp;

    // decrement
    i++;

    if (next_val == range) {
      next_val = next_val >> 1;
      nb_bits--;
    }
    range--;
  }
}

#endif
