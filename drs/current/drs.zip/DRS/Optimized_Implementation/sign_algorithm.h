#ifndef SIGN_H
#define SIGN_H

#include "crypto_struct.h"

double sign_reduction = 0, sign_build_q = 0;
double sign_rdm = 0;
double sign_permut = 0;
uint64_t sgn_nb_rdm_bits_used = 0;
clock_t tsgn_0, tsgn_1;

// reduce the message using the secret key, and then stores information in the
// signature structure
void reductionS_D(signature *s, message *m, secret_key *sk) {

  unsigned int i = 0, k = 0, j = 0;
  int64_t q, qi[_DIM_];
  memset(qi, 0, _DIM_ * sizeof(int64_t));
// reduce the message with the reduction matrix
#define _LIMIT_32_BITS_RED (((INT64_C(1) << 31)) / (_DIM_ * _D_BOUND_))
  // first pass to check the 32-bit conversion bound
  do {
    q = m->dat[i] / _D_BOUND_;
    if (q > _LIMIT_32_BITS_RED) {
      qi[i] += q;
      for (j = 0; j < _DIM_; j++) {
        m->dat[j] -= q * ((int64_t)sk->A.dat[i][j]);
      }
      k = 0;
    }
    k++;
    i = (i + 1) % (_DIM_);
  } while (k != (_DIM_));

  // do the conversion to 32-bit vector
  int32_t *vec32 = (int32_t *)(m->dat);
  for (size_t i = 0; i < _DIM_; i++) {
    vec32[i] = (int32_t)(m->dat[i]);
  }

  // reduce using 32-bits integers
  int32_t q32 = 0;
  do {
    q32 = vec32[i] / _D_BOUND_;
    if (q32) {
      qi[i] += q32;
      for (j = 0; j < _DIM_; j++) {
        vec32[j] -= q32 * (sk->A.dat[i][j]);
      }
      k = 0;
    }
    k++;
    i = (i + 1) % (_DIM_);
  } while (k != (_DIM_));
  // Turn back the vector into 64-bits
  for (int i = _DIM_ - 1; i >= 0; i--) {
    m->dat[i] = vec32[i];
  }

  // update the signature information
  for (unsigned int i = 0; i < _DIM_; i++) {
    s->dat[i] = m->dat[i];
    // this is slightly modified part
    s->k[i] = qi[i];
  }
  // use the secret seed to obtain the extra information k
  // initialize the randomness, to simulate the multiplication by the inverse of
  // U
  UniRandSeed(sk->RandSeed);

  // contruct the vector
  // precompute all signs
  const size_t nb_signs_64 = (((NB_ROUNDS * _DIM_ / 2) - 1) / 64) + 1;
  int64_t signs[nb_signs_64];
  size_t signs_pos_array = 0;
  size_t signs_pos_bit = 0;
  // load it all
  seedexpander(_UniRand_, (unsigned char *)(signs), nb_signs_64 * 8);

  for (size_t k = 0; k < NB_ROUNDS; k++) {

    // call the random generator
    _UniIncreasingRandom_Permut_2((int64_t *)s->k, _DIM_, _BITS_DIM);
    // apply the DEFAULT_NB_ROUNDS
    // use the loaded signs
    for (size_t i = 0; i < _DIM_ - 1;) {
      for (; signs_pos_bit < 64 && i < _DIM_ - 1; signs_pos_bit++, i += 2) {
        // increment index for either positive or negative

        // // METHOD 1
        // int64_t sgn = (((signs[signs_pos_array] & 1) << 1) - 1);
        // signs[signs_pos_array] >>= 1;
        // s->k[i + 1] = s->k[i + 1] - sgn * (s->k[i]);
        // s->k[i] = s->k[i] - sgn * (s->k[i + 1]);

        // METHOD 2
        int64_t sgn = signs[signs_pos_array] >> 63;
        signs[signs_pos_array] <<= 1;
        s->k[i + 1] = s->k[i + 1] + ((s->k[i] ^ sgn) - sgn);
        s->k[i] = s->k[i] + ((s->k[i + 1] ^ sgn) - sgn);
      }
      // switch to next pack of 64_bit
      signs_pos_bit &= 63;
      signs_pos_array += (!signs_pos_bit);
    }
  }
  // call the random generator one last time
  _UniIncreasingRandom_Permut_2((int64_t *)s->k, _DIM_, _BITS_DIM);
}

// a stapleholder with a simple name
void sign(message *m, signature *s, secret_key *sk) { reductionS_D(s, m, sk); }

#endif // SIGN_H
