#ifndef _SHAKE_512_H
#define _SHAKE_512_H

#include "Keccak-readable-and-compact.c"

/**
  *  Function to compute SHAKE512 on the input message with any output length.
  */
void SHAKE512(const unsigned char *input, unsigned int inputByteLen, unsigned char *output, int outputByteLen)
{
    // capacity, twice the security level c = 2 * 512 = 1024
    // rate r = 1600 - c = 1600 - 1024 = 576
    Keccak(576, 1024, input, inputByteLen, 0x1F, output, outputByteLen);
}

#endif
