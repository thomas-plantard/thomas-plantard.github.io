#ifndef _CHAR_KEY_CONV_H
#define _CHAR_KEY_CONV_H

#include "crypto_struct.h"
#include "SHAKE512.h"

//bit by bit printing, so first bit of the character is the first printed
void print_bin_char_array(unsigned char* array, unsigned int size){
  for (size_t i = 0; i < size; i++) {
    printf("%d", (array[i] & 1));
    printf("%d", (array[i] & 2)>>1);
    printf("%d", (array[i] & 4)>>2);
    printf("%d", (array[i] & 8)>>3);
    printf("%d", (array[i] & 16)>>4);
    printf("%d", (array[i] & 32)>>5);
    printf("%d", (array[i] & 64)>>6);
    printf("%d", (array[i] & 128)>>7);
    printf(" ");
  }
}

// function to advance over an array, capturing a certain amount of bits
// returns the corresponding integer in a uint64_t structure
// longer than 64 bits is not implemented yet (but probably not needed)
int64_t
capture_bits(unsigned char** array, unsigned int* current_bit, unsigned int wanted_bits){
  if (wanted_bits>64) {fprintf(stderr, "capture-bits: wanted_bits %u is too big (>64)\n", wanted_bits);return 0;}

  unsigned char _masks_add[8]={1,2,4,8,16,32,64,128};
  int64_t res=0;

  for (size_t i = 0; i < wanted_bits; i++) {
    res=(res<<1);
    res+=( ((**array)&_masks_add[*current_bit]) >> (*current_bit) );
    (*current_bit)++;
    if ((*current_bit)==8) {(*array)++;(*current_bit)=0;}
  }
  return res;
}

// in the character array, write the number given in reversed bit order
// get the pointer and current bit of the position we want to start writing
void
write_bits(unsigned char** array, unsigned int* current_bit, unsigned int nb_bits, int64_t bits_to_write) {
  if (nb_bits>64) {fprintf(stderr, "write_bits nb_bits %u is too big (>64)\n", nb_bits);return ;}

  // for deleting bits
  unsigned char _masks_del[8]={255-1,255-2,255-4,255-8,255-16,255-32,255-64,255-128};

  //the buffer, removes bits we don't need
  int64_t buff = ((bits_to_write << (64-nb_bits)) >> (64-nb_bits) );
  char bit_to_write;

  for (size_t i = 0; i < nb_bits; i++) {
    // if we write into a new position, reset the bit
    // if (!(*current_bit)) {(**array)=0;}
    (**array)=(**array) & _masks_del[*current_bit];
    bit_to_write=( buff >> (nb_bits-1-i) ) & 1;
    //printf("bit %ld = %ld\n",i,bit_to_write);
    (**array)+=( bit_to_write << (*current_bit) );
    //bits_to_write=(bits_to_write>>1);
    (*current_bit)++;
    // resets the char to 0 before doing operation on it
    if ((*current_bit)==8) {(*array)++;(*current_bit)=0;}
  }
}


void
sk_to_c(unsigned char* c, const secret_key* sk){

  for (size_t i = 0; i < SEED_SIZE; i++) {
    c[i]=sk->RandSeed[i];
  }

  // copy of the indexes, to pass to the writing functions
  unsigned char* tmp;
  // starts from after the seed
  tmp=c+SEED_SIZE;
  unsigned int current_bit=0;

  // all the necessary information for Bs and Ones
  unsigned int b_cnt=0;
  unsigned int o_cnt=0;
  unsigned int B_POS[_NB_B_];
  unsigned int O_POS[_NB_ONES_];

  // first of all, write the matrix reduction

  // the first vector, excluding the big coefficent, has three values with a majority of zeroes
  // so if 0 -> 0, if +/-B -> 11, and if +/-1 -> 10
  // ignore the first value sk->A.dat[0][0]=D since it doesn't change
  // memorize the position of Bs and 1s for the sign
  for (size_t i = 1; i < _DIM_; i++) {
    if (!(sk->A.dat[0][i])) {
      // case 0
      write_bits(&tmp,&current_bit,1,0);
    } else if (ABS(sk->A.dat[0][i])==1) {
      // case 1 : clearly not optimized but not taking risks
      write_bits(&tmp,&current_bit,1,1);
      write_bits(&tmp,&current_bit,1,0);
      // take the One position and count it
      O_POS[o_cnt]=i;
      o_cnt++;
    } else if (ABS(sk->A.dat[0][i])==_B_VAL_) {
      // case B : low optimization level indeed
      write_bits(&tmp,&current_bit,1,1);
      write_bits(&tmp,&current_bit,1,1);
      // take the B position and count it
      B_POS[b_cnt]=i;
      b_cnt++;
    } else {
      // we have a problem
      fprintf(stderr, "sk_to_c : INVALID SECRET KEY : WRONG VALUE COUNTED\n");exit(1);
    }
  }
  // at the end we should have counted _NB_B_==b_cnt and _NB_ONES_=o_cnt
  if ((_NB_B_!=b_cnt) || ((_NB_ONES_)!=o_cnt) ) {
    fprintf(stderr, " sk_to_c : INVALID SECRET KEY : WRONG COUNT OF BS AND ONES\n");exit(1);}

  // now we fill the sign information
  // 1 for positive, 0 for negative
  for (size_t i = 0; i < _DIM_; i++) {
    // for the Bs
    for (size_t j = 0; j < _NB_B_; j++) {
      if ( (sk->A.dat[i][B_POS[j]]) > 0 )
      {write_bits(&tmp,&current_bit,1,1);}
      else {write_bits(&tmp,&current_bit,1,0);}
      // update B_POS for the next vector
      B_POS[j]=( (B_POS[j]+1) % _DIM_);
    }
    // for the Ones
    for (size_t j = 0; j < (_NB_ONES_); j++) {
      if ( (sk->A.dat[i][O_POS[j]]) > 0 )
      {write_bits(&tmp,&current_bit,1,1);}
      else {write_bits(&tmp,&current_bit,1,0);}
      // update O_POS for the next vector
      O_POS[j]=( (O_POS[j]+1) % _DIM_);
    }
  }
}

// reversed function, from the character array to the secret keys
// we suppose, of course, that sk is all allocated with full of zeroes
void
c_to_sk(secret_key* sk, const unsigned char* c){
  // copy of the indexes, to pass to the reading functions

  for (size_t i = 0; i < SEED_SIZE; i++) {
    sk->RandSeed[i]=c[i];
  }

  unsigned char* tmp;
  // starts from after the seed
  tmp=((unsigned char*)c)+SEED_SIZE;
  unsigned int current_bit=0;

  // all the necessary information for Bs and Ones
  unsigned int b_cnt=0;
  unsigned int o_cnt=0;
  unsigned int B_POS[_NB_B_];
  unsigned int O_POS[_NB_ONES_];

  // first, get the positions of Ones and Bs
  for (size_t i = 1; i < _DIM_; i++) {
    // scan if we get a 1
    if (capture_bits(&tmp,&current_bit,1)) {
      // check the next bit to determine if it's a B or a ONE
      if (capture_bits(&tmp,&current_bit,1)) {
        // it's a B
        B_POS[b_cnt]=i;b_cnt++;
      } else {
        // it's a one
        O_POS[o_cnt]=i;o_cnt++;
      }
    }
  }

  // at the end we should have counted _NB_B_==b_cnt and _NB_ONES_=o_cnt
  if ((_NB_B_!=b_cnt) || ((_NB_ONES_)!=o_cnt) ) {
    fprintf(stderr, " c_to_sk : INVALID SECRET KEY : WRONG COUNT OF BS AND ONES\n");exit(1);}

  int sgn = 0;
  // now that we got the position for Bs and ONEs, we fill the reduction matrix
  for (size_t i = 0; i < _DIM_; i++) {
    sk->A.dat[i][i]=_D_BOUND_;
    // fill the Bs
    for (size_t j = 0; j < _NB_B_; j++) {
      // get the sign, fill the B
      sgn = ( ( capture_bits(&tmp,&current_bit,1) * 2 ) - 1);
      sk->A.dat[i][B_POS[j]] = (sgn * _B_VAL_);
      // update B_POS for the next vector
      B_POS[j]=( (B_POS[j]+1) % _DIM_);
    }
    // fill the ONEs
    for (size_t j = 0; j < (_NB_ONES_); j++) {
      // get the sign, fill the B
      sgn = ( ( capture_bits(&tmp,&current_bit,1) * 2 ) - 1);
      sk->A.dat[i][O_POS[j]] = sgn;
      // update O_POS for the next vector
      O_POS[j]=( (O_POS[j]+1) % _DIM_);
    }
  }
}

// print the public key in a character array
void
pk_to_c(unsigned char* c, const public_key* pk) {
  // copy of the indexes, to pass to the writing functions
  unsigned char* tmp;tmp=c;
  unsigned int current_bit=0;

  // this one is pretty straightforward, just scan each coefficient
  for (size_t i = 0; i < _DIM_; i++) {
    for (size_t j = 0; j < _DIM_; j++) {
      if ( (pk->dat[i][j]) > 0 ){write_bits(&tmp,&current_bit,1,1);}
      else {write_bits(&tmp,&current_bit,1,0);}
      write_bits(&tmp,&current_bit,_SIZE_P_COEF,ABS(pk->dat[i][j]));
    }
  }
  // for the power of 2 data used for the verification
  // 7 bits because right now we use 2^64 as a maximum
  write_bits(&tmp,&current_bit,7,Log2_64(pk->log_reduc));
}

// reverse operation
void
c_to_pk(public_key* pk, const unsigned char* c) {
  // copy of the indexes, to pass to the writing functions
  unsigned char* tmp;tmp=(unsigned char*)c;
  unsigned int current_bit=0;

  // this one is pretty straightforward, just scan each coefficient
  int sgn;
  for (size_t i = 0; i < _DIM_; i++) {
    for (size_t j = 0; j < _DIM_; j++) {
      // get the sign first, then get the value to multiply with the sign
      sgn = ( ( capture_bits(&tmp,&current_bit,1) * 2 ) - 1);
      pk->dat[i][j] = sgn * capture_bits(&tmp,&current_bit,_SIZE_P_COEF);
    }
  }

  // for the power of 2 data used for the verification
  // 7 bits because right now we use 2^64 as a maximum
  pk->log_reduc=capture_bits(&tmp,&current_bit,7);
  pk->log_reduc=( ((uint64_t)1) << ((pk->log_reduc) - 1));
}

// print the signature in a character array
void
sgn_to_c(unsigned char* c, const signature* s) {
  // copy of the indexes, to pass to the writing functions
  unsigned char* tmp;tmp=c;
  unsigned int current_bit=0;

  // First, the small vector part
  // this one is pretty straightforward, the limit of bits is :
  // _BITS_D_BD and of course, +1 for the sign (for each coefficient)
  for (size_t i = 0; i < _DIM_; i++) {
    if ( (s->dat[i]) > 0 ){write_bits(&tmp,&current_bit,1,1);}
    else {write_bits(&tmp,&current_bit,1,0);}
    write_bits(&tmp,&current_bit,_BITS_D_BD,ABS(s->dat[i]));
  }

  // for the q part, just write the 64bits (no bounds on q) (for each coefficient)
  for (size_t i = 0; i < _DIM_; i++) {
    write_bits(&tmp,&current_bit,64,s->k[i]);
  }
}

// reversed part
void
c_to_sgn(signature* s, const unsigned char* c) {
  // copy of the indexes, to pass to the writing functions
  unsigned char* tmp;tmp=(unsigned char*)c;
  unsigned int current_bit=0;

  // First, the small vector part
  // this one is pretty straightforward, the limit of bits is :
  // _BITS_D_BD and of course, +1 for the sign (for each coefficient)
  int sgn;
  for (size_t i = 0; i < _DIM_; i++) {
    sgn = ( ( capture_bits(&tmp,&current_bit,1) * 2 ) - 1);
    s->dat[i] = sgn * capture_bits(&tmp,&current_bit,_BITS_D_BD);
  }

  // for the q part, just get the 64bits (no bounds on q) (for each coefficient)
  for (size_t i = 0; i < _DIM_; i++) {
    s->k[i] = capture_bits(&tmp,&current_bit,64);
  }
}

/**************************************/
/*                                    */
/*    Hashing into message space      */
/*                                    */
/**************************************/
// FUNCTION COME WITHOUT INITS

void
hashed_message(message* hash_m, const unsigned char* m, unsigned long long mlen) {
  unsigned char bytes[MSG_VECTOR_BYTES];
  // copy of the indexes, to pass to the writing functions
  unsigned int current_bit=0;
  unsigned char* tmp;tmp=(unsigned char*)bytes;
  SHAKE512(m,mlen,bytes,MSG_VECTOR_BYTES);

  int64_t sgn,value;
  for (size_t i = 0; i < _DIM_; i++) {
    sgn = ( ( capture_bits(&tmp,&current_bit,1) * 2 ) - 1);
    value = capture_bits(&tmp,&current_bit,LOG_LIMIT_M);
    // (hash_m)->dat[i] = ( value * sgn );
    (hash_m)->dat[i] = ( value );
  }

}

#endif
