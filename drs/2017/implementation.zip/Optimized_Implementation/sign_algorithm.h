#ifndef SIGN_H
#define SIGN_H

#include "crypto_struct.h"

// reduce the message using the secret key, and then stores information in the signature structure
void
reductionS_D(signature *s, message *m, secret_key *sk) {
    unsigned int i = 0, k = 0, j = 0;
    int64_t q, qi[_DIM_];
    memset(qi, 0, _DIM_*sizeof(int64_t));
    // reduce the message with the reduction matrix
    do {
        q = m->dat[i]/_D_BOUND_;
        if(q) {
            qi[i] += q;
            for(j = 0; j < _DIM_; j ++)
              {m->dat[j] -= q*((int64_t)sk->A.dat[i][j]);}
            k = 0;
        }
        k++;
        i = (i + 1) % (_DIM_);
    } while(k != (_DIM_));
    //update the signature information
    for(unsigned int i = 0; i < _DIM_; i++) {
        s->dat[i] = m->dat[i];
        // this is slightly modified part
        s->k[i] = qi[i];
    }
    // use the secret seed to obtain the extra information k
    // initialize the randomness, to simulate the multiplication by the inverse of U
    UniRandSeed(sk->RandSeed);
    int64_t sgn;
    for (size_t i = 0; i < NB_ROUNDS; i++) {
      //call the random generator
      _permut_elts(s->k);
      //apply the DEFAULT_NB_ROUNDS
      for(unsigned int i = 0; i < (_DIM_ - 1); i+=2) {
        sgn=UniRandSgn();
        s->k[i+1] = s->k[i+1] - sgn*(s->k[i]);
        s->k[i] = s->k[i] - sgn*(s->k[i+1]);
      }
    }
    //call the random generator one last time
    _permut_elts(s->k);
}

// a stapleholder with a simple name
void
sign(message *m, signature *s, secret_key *sk) {
    reductionS_D(s, m, sk);
}

#endif //SIGN_H
