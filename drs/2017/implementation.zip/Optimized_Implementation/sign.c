#include "custom_rand.h"
#include "crypto_struct.h"
#include "sign_algorithm.h"
#include "setup.h"
#include "verify.h"
#include "char_key_conv.h"

int
crypto_sign_keypair(unsigned char *pk, unsigned char *sk)
{
  memset(pk, 0x00, CRYPTO_PUBLICKEYBYTES);
  memset(sk, 0x00, CRYPTO_SECRETKEYBYTES);

  // get a seed for the key setup
  unsigned char seed[32];
  randombytes(seed,32);

  // create the structures
  secret_key *sk2;init_secret_key(&sk2);secret_key_setup(sk2,seed);
  public_key *pk2;init_public_key(&pk2);key_setup(pk2,sk2);

  // export to char
  pk_to_c(pk,pk2);
  sk_to_c(sk,sk2);

  // delete structures
  free_secret_key(sk2);
  free_public_key(pk2);

  // we shouldn't ever get a problem with generation
  return 0;
}

int
crypto_sign(unsigned char *sm, unsigned long long *smlen,
	const unsigned char *m, unsigned long long mlen,
	const unsigned char *sk)
{
  // let's not sign emptiness
  if(!mlen){fprintf(stderr,"Don't sign empty messages\n");return -1;}

  // put the message into the signature
  *smlen=CRYPTO_BYTES+mlen;
  memset(sm, 0x00, CRYPTO_BYTES);
  for (size_t i = 0; i < mlen; i++) {
    sm[i+CRYPTO_BYTES]=m[i];
  }

  // create the structures
  secret_key *sk2;init_secret_key(&sk2);c_to_sk(sk2,sk);
  message* hm;init_message(&hm);hashed_message(hm,m,mlen);
  signature *s;init_signature(&s);

  //we sign a copy to avoid modification of the message
  message* m_cpy;init_message(&m_cpy);
  for(unsigned int i = 0; i < _DIM_; i++) {
      m_cpy->dat[i] = hm->dat[i];
  }

  // sign
  sign(m_cpy,s,sk2);

  // recover the signature in chars
  sgn_to_c(sm,s);

  // free the memory
  free_secret_key(sk2);
  free_message(hm);free_message(m_cpy);
  free_signature(s);

  //unless you get a faulty system
  //you should be able to sign anything since we hash any non-empty message to the message space
  return 0;
}

int
crypto_sign_open(unsigned char *m, unsigned long long *mlen,
	const unsigned char *sm, unsigned long long smlen,
	const unsigned char *pk_c)
{
  int res;

  // extract the message from sm, put it into m
  *mlen=smlen-CRYPTO_BYTES;
  for (size_t i = 0; i < *mlen; i++) {
    m[i]=sm[i+CRYPTO_BYTES];
  }

  // create the structures
  signature *s;init_signature(&s);c_to_sgn(s,sm);
  message* msg;init_message(&msg);hashed_message(msg,m,*mlen);
  public_key *pk;init_public_key(&pk);c_to_pk(pk,pk_c);

  // verify (the output of verify can indicate the type of error)
  // this can be changed in the source code
  res=verify(msg, s, pk);

  // free the memory
  free_public_key(pk);
  free_message(msg);
  free_signature(s);

  return res;
}
