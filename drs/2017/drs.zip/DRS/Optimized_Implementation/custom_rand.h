#ifndef _CUSTOM_RAND_H_
#define _CUSTOM_RAND_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <string.h>

#include "api.h"
#include "rng.h"

/**************************************/
/*                                    */
/*        WITH UNIVERSAL SEEDS        */
/*                                    */
/**************************************/

// array of values, all values lower than 16 bits (assuming _DIM_ is lower than 16 bits)
// at the end, values[x] must be a random value strictly inferior or equal to x
unsigned short int _values_[_DIM_]={0};

AES_XOF_struct _UniRand_[1];
// this is clearly an arbitrary initializer: you can change those as you see fit
unsigned char _UniversalDiversifier_[8]={1,1,1,1,1,1,1,1};

//defines the number of 64_bits packages we store and generate at a time (with seedexpander)
#define _UniNb64_ (4)
#define _Unixlen_ (8*_UniNb64_)

// This is our global storage or randomly generated bits that our functions will tap into
typedef union {
  unsigned char C[_Unixlen_];
  uint64_t I[_UniNb64_];
}_UniRandStruct_;
_UniRandStruct_ _UniRandStore_;

// helps us track how much bits/uint64_t we have have used so far
int _UniPosNb64_ = 0;
int _UniPosBit64_ = 0;

void
UniRandSeed(unsigned char* seed)
{
  //need to initialize only once
  seedexpander_init(_UniRand_,seed,_UniversalDiversifier_,UINT32_MAX);
  // call the first random series
  seedexpander(_UniRand_,(_UniRandStore_.C),_Unixlen_);
  // sets our initial position
  _UniPosNb64_=0;_UniPosBit64_=0;
}

int
UniRandSgn(){
  int res;
  // did we use all 64bits integers of our big char array?
  if(_UniPosNb64_<(_UniNb64_)){
    // did we use all 64 bits of our current part?
    if (_UniPosBit64_< 64) {
      // take last bit to decide whether we have 1 or -1
      res = ( ( (_UniRandStore_.I[_UniPosNb64_] & 1) * 2 ) - 1 );
      _UniRandStore_.I[_UniPosNb64_]=((_UniRandStore_.I[_UniPosNb64_])>>1);
      _UniPosBit64_++;
      return res;
    } else {
      // we used all 64 bits and need to change part
      _UniPosNb64_++;
      _UniPosBit64_=0;
      // take last bit to decide whether we have 1 or -1
      res = ( ( (_UniRandStore_.I[_UniPosNb64_] & 1) * 2 ) - 1 );
      _UniRandStore_.I[_UniPosNb64_]=((_UniRandStore_.I[_UniPosNb64_])>>1);
      _UniPosBit64_++;
      return res;
    }
  } else {
    // we need to generate a new big stock of bits, and reset the counters
    _UniPosNb64_= 0;
    _UniPosBit64_= 0;
    seedexpander(_UniRand_,(_UniRandStore_.C),_Unixlen_);
    // take last bit to decide whether we have 1 or -1
    res = ( ( (_UniRandStore_.I[_UniPosNb64_] & 1) * 2 ) - 1 );
    _UniRandStore_.I[_UniPosNb64_]=((_UniRandStore_.I[_UniPosNb64_])>>1);
    _UniPosBit64_++;
    return res;
  }
}

void
_UniIncreasingRandom_(){
  // - position in the array (start at 1 because pos 0 will only give 0)
  // - position of the highest bit, and next value before we change the highbit
  // - mask that helps extracting the value we get from our random bits
  // - temporary variable used before we decide whether we take it or reject it

  int pos=1;
  int highbit=1;
  int next_value=2;
  uint64_t mask=1;
  unsigned int tmp=0;
  // until we reach the end of the array
  while (pos<_DIM_) {
    // until we change the highbit or reach the end of the array
    while (!(next_value & pos) && (pos<_DIM_)) {
      // TEST : Enough bits left in _DimRandStruct_.I[_DimPosNb64_] ?
      if (_UniPosNb64_!=_UniNb64_) {
        // We still haven't used the last bit
        if (_UniPosBit64_<(64-highbit)) {
          // - get our value, thanks to the mask
          // - update our random bit series
          // - update our number of bits used
          tmp=(_UniRandStore_.I[_UniPosNb64_] & mask);
          _UniRandStore_.I[_UniPosNb64_]=((_UniRandStore_.I[_UniPosNb64_])>>highbit);
          _UniPosBit64_+=highbit;
        } else {
          // don't have enough bits, we have to use leftovers anyway so :
          // - get leftover bits first
          // - update the position of the used 64 bit integer
          tmp=(_UniRandStore_.I[_UniPosNb64_] & mask);
          _UniPosNb64_++;
          // TEST : Enough 64 bits integers left in _DimRandStruct_.I ?
          if (_UniPosNb64_!=_UniNb64_) {
            // - get the bits we want (right shift by #leftover bits taken, then use mask)
            // - update the number of bits used in our new _DimRandStore_.I[_DimPosNb64_]
            tmp+=(uint16_t)( ( _UniRandStore_.I[_UniPosNb64_] << (64 - _UniPosBit64_) ) & mask );
            _UniPosBit64_= highbit - (64 - _UniPosBit64_);
            _UniRandStore_.I[_UniPosNb64_]=((_UniRandStore_.I[_UniPosNb64_])>>_UniPosBit64_);
          } else {
            // if we used every 64bit integer we have to recall our random generator
            _UniPosNb64_=0;
            seedexpander(_UniRand_,(_UniRandStore_.C),_Unixlen_);
            // - get the bits we want (right shift by #leftover bits taken, then use mask)
            // - update the number of bits used in our new _DimRandStore_.I[_DimPosNb64_]
            tmp+=(uint16_t)( ( _UniRandStore_.I[_UniPosNb64_] << (64 - _UniPosBit64_) ) & mask );
            _UniPosBit64_= highbit - (64 - _UniPosBit64_);
            _UniRandStore_.I[_UniPosNb64_]=((_UniRandStore_.I[_UniPosNb64_])>>_UniPosBit64_);
          }
        }
      } else {
        // if we used every 64bit integer we have to recall our random generator
        _UniPosNb64_=0;
        _UniPosBit64_=0;
        seedexpander(_UniRand_,(_UniRandStore_.C),_Unixlen_);
        // apply our extraction technique, the mask should still be lower than 64 bits.
        tmp=(_UniRandStore_.I[_UniPosNb64_] & mask);
        _UniRandStore_.I[_UniPosNb64_]=((_UniRandStore_.I[_UniPosNb64_])>>highbit);
        _UniPosBit64_+=highbit;
      }
      // TEST: value <= pos -> stores the value, update pos
      if(tmp<=pos){_values_[pos]=(uint16_t)tmp;pos++;}
    }
    // - change the highbit and reinitialize the number of call left before next change
    // - update our mask too.
    next_value=(next_value<<1);
    highbit++;
    mask=((mask<<1)+1);
  }
}

// those two functions can be simplified by a void* cast
// for lisibility, we use them
void
_permut_rows(int64_t** matrix){
  // call the position permutation function
  _UniIncreasingRandom_();
  unsigned int j;
  int64_t* tmp;
  // use that position array to permute elements
  for(unsigned int i = 0; i < _DIM_; i++) {
      j=_values_[_DIM_- i - 1];
      if(j) {tmp = matrix[i]; matrix[i] = matrix[i+j]; matrix[i+j] = tmp;}
  }
}

void
_permut_elts(int64_t* array) {
  // call the position permutation function
  _UniIncreasingRandom_();
  unsigned int j;
  int64_t tmp;
  // use that position array to permute elements
  for(unsigned int i = 0; i < _DIM_; i++) {
      j=_values_[_DIM_- i - 1];
      if(j) {tmp = array[i]; array[i] = array[i+j]; array[i+j] = tmp;}
  }
}

#endif
