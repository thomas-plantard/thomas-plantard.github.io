#ifndef VERIFY_H
#define VERIFY_H

#include "crypto_struct.h"

#define ABS(x) ((x) > 0 ? (x): -(x))

#define _DELTA (pk->log_reduc)
#define t64i(x) ((int64_t)(x))

int64_t
verify(message *m, signature *s, public_key *pk) {
  int64_t rP[_DIM_], r[_DIM_], q[_DIM_], t[_DIM_], tmp, t_nonzero=1,q_nonzero=1;

  // check for max norm first
  for(unsigned int i = 0; i < _DIM_; i++) {
    if(ABS(s->dat[i]) >= _D_BOUND_) {
      fprintf(stderr,"signature not low enough\n");
      return -1;
    }
  }

  // Loop initialization part
  for(unsigned int i = 0; i < _DIM_; i++) {
    q[i] = (s->k[i]);
    t[i] = t64i(m->dat[i]) - t64i(s->dat[i]);
  }
  // loop start
  while (t_nonzero & q_nonzero) {
    // compute the value r to multiply by P
    for(unsigned int i = 0; i < _DIM_; i++) {
      tmp = q[i] / _DELTA;
      r[i] = q[i]- (tmp*_DELTA);
    }

    // this should stay zero if t reduced itself to 0, and shouldn't overflow
    // (at worst it's the size of the message dividided by p_2 times the dimension)
    t_nonzero = 0;
    // compute rP, then t-rP
    for(unsigned int i = 0; i < _DIM_; i++) {
      rP[i] = 0;
      for(unsigned int j = 0; j < _DIM_; j++)
        {rP[i] += r[j] * t64i(pk->dat[i][j]);}

      // check divisibility
      tmp = (t[i]-rP[i]) / _DELTA;
      if( (tmp*_DELTA) != (t[i]-rP[i]) ) {return -1;}
      // otherwise divide by p_2, to update t, not sure if we have to add -r[i].
      t[i] = tmp;
      t_nonzero+=ABS(t[i]);
    }

    // this should stay zero if q reduced itself to 0
    // this should also not overflow
    q_nonzero=0;
    // update q
    for (size_t i = 0; i < _DIM_; i++) {
      q[i] = (q[i]-r[i]) / _DELTA;
      q_nonzero+=ABS(q[i]);
    }
    // another check for invalid terms (one reduced to zero early)
    if (!q_nonzero != !t_nonzero) {return -1;}
  }
  return 0;
}

#endif //VERIFY_H
