#ifndef SETUP_H
#define SETUP_H

#include "crypto_struct.h"
#include <math.h>

#define ABS(x) ((x) > 0 ? (x): -(x))

// Constructs the matrix public key
void
public_key_construct(int64_t **A, unsigned char* seed) {
    int64_t sgn;
    // initialize the randomness with the given seed
    UniRandSeed(seed);
    // Now creates the final public key matrix
    for (size_t i = 0; i < NB_ROUNDS; i++) {
      //call the random generator
      _permut_rows(A);
      //apply the DEFAULT_NB_ROUNDS
      for(unsigned int i = 0; i < (_DIM_ - 1); i+=2) {
        sgn=UniRandSgn();
        for(unsigned int k = 0; k < _DIM_; k++) {
          A[i][k] = A[i][k] + sgn*A[i+1][k];
          // U[i+1][k] = U[i+1][k] - sgn*U[i][k];
          A[i+1][k] = A[i+1][k] + sgn*A[i][k];
          // U[i][k] = U[i][k] - sgn*U[i+1][k];
        }
      }
    }
    //call the random generator one last time
    _permut_rows(A);
}

// transpose the matrix (useful when multiplying by row vectors)
void
transpose_key(int64_t **mat) {
    int64_t tmp;
    for(unsigned int i = 0; i < _DIM_; i++) {
        for(unsigned int j = i + 1; j < _DIM_; j++) {
            tmp = mat[i][j];
            mat[i][j] = mat[j][i];
            mat[j][i] = tmp;
        }
    }
}

void
secret_key_setup(secret_key *sk, unsigned char* init_seed) {
    // use another temporary seed for the secret key
    AES_XOF_struct ctx[1];
    unsigned char sk_seed[32];
    unsigned char pk_seed[32];
    seedexpander_init(ctx,init_seed,_UniversalDiversifier_,UINT32_MAX);
    seedexpander(ctx, sk_seed, 32);seedexpander(ctx, pk_seed, 32);
    // this seed will be used for the generation of the public key and signing
    for (size_t i = 0; i < 32; i++) {sk->RandSeed[i]=pk_seed[i];}
    // the other
    UniRandSeed(sk_seed);

    int32_t i = 0;
    unsigned int j = 0;
    int32_t vec_tmp[_DIM_];
    vec_tmp[0] = _DIM_;
    size_t t =1;
    // fill the initial vector
    for (; t < _NB_B_+1; t++) {vec_tmp[t]=_B_VAL_;}
    for (; t < _NB_ONES_+_NB_B_+1; t++) {vec_tmp[t]=1;}
    for (; t < _DIM_; t++) {vec_tmp[t]=0;}
    // permutes elements of the initial vector
    // works exactly the same as the other permutation functions, but use a int32_t array
    _UniIncreasingRandom_();
    for(size_t k = 0; k < _DIM_-1; k++) {
        j=_values_[_DIM_- k-2];
        if(j) {
            i = vec_tmp[k+1];
            vec_tmp[k+1] = vec_tmp[k+1+j];
            vec_tmp[k+1+j] = i;
        }
    }
    // place and shift
    for(i = 0; i < _DIM_; i++) {
        sk->A.dat[i][i] = vec_tmp[0];
        for(unsigned int j = 1; j < _DIM_; j++) {
            sk->A.dat[i][(i + j) % _DIM_] = vec_tmp[j]*(UniRandSgn());
        }
    }
}

//given sk, setup pk
void
key_setup(public_key *pk, secret_key *sk) {
    //transfer values
    for(unsigned int i = 0; i < _DIM_; i++) {
        for(unsigned int j = 0; j < _DIM_; j++) {
            pk->dat[i][j] = (int64_t)sk->A.dat[i][j];
        }
    }
    // fill
    public_key_construct(pk->dat, sk->RandSeed);
    transpose_key(pk->dat);
    // compute the max norm of the matrix (the matrix is already transposed)
    uint64_t m_norm[_DIM_];
    for (size_t i = 0; i < _DIM_; i++) {
      m_norm[i]=0;
      for (size_t j = 0; j < _DIM_; j++) {
        m_norm[i]+=ABS(pk->dat[i][j]);
      }
    }
    // get the specific divisor for the verification function
    pk->log_reduc=m_norm[0];
    for (size_t i = 1; i < _DIM_; i++) {
      if (m_norm[i]>pk->log_reduc) {pk->log_reduc=m_norm[i];}
    }
    pk->log_reduc=(((uint64_t)1)<<(62-Log2_64(pk->log_reduc)));
}

//given a seed, set up both keys
void
setup(secret_key *sk, public_key *pk, unsigned char* seed) {
  secret_key_setup(sk,seed);
  key_setup(pk, sk);
}

// recovering the original 64-bits matrix, for test purpose only! (no initial reduction matrix)
void
key_setup2(public_key *pk, secret_key *sk, int64_t** PK) {
    //allocate
    for(unsigned int i = 0; i < _DIM_; i++) {
      PK[i] = (int64_t*)malloc(_DIM_*sizeof(int64_t));
      for(unsigned int j = 0; j < _DIM_; j++) {
        PK[i][j] = (int64_t)sk->A.dat[i][j];
      }
    }
    // fill
    public_key_construct(PK, sk->RandSeed);
    transpose_key(PK);
    for(unsigned int i = 0; i < _DIM_; i++) {
        for(unsigned int j = 0; j < _DIM_; j++) {
            pk->dat[i][j] = PK[i][j];
        }
    }
    // compute the max norm of the matrix (the matrix is already transposed)
    uint64_t m_norm[_DIM_];
    for (size_t i = 0; i < _DIM_; i++) {
      m_norm[i]=0;
      for (size_t j = 0; j < _DIM_; j++) {
        m_norm[i]+=ABS(pk->dat[i][j]);
      }
    }
    // get the specific divisor for the verification
    pk->log_reduc=m_norm[0];
    for (size_t i = 1; i < _DIM_; i++) {
      if (m_norm[i]>pk->log_reduc) {pk->log_reduc=m_norm[i];}
    }
    pk->log_reduc=(((uint64_t)1)<<(62-Log2_64(pk->log_reduc)));
}

void
setup2(secret_key *sk, public_key *pk, unsigned char* seed, int64_t** PK) {
  secret_key_setup(sk,seed);
  key_setup2(pk, sk, PK);
}

#endif //SETUP_H
