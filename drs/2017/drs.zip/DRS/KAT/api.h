#ifndef api_h
#define api_h

int
crypto_sign_keypair(unsigned char *pk, unsigned char *sk);
int
crypto_sign(unsigned char *sm, unsigned long long *smlen,
  const unsigned char *m, unsigned long long mlen,
  const unsigned char *sk);
int
crypto_sign_open(unsigned char *m, unsigned long long *mlen,
  const unsigned char *sm, unsigned long long smlen,
  const unsigned char *pk);

// KAT and SUPERCOP constants
#define CRYPTO_PUBLICKEYBYTES 28987
#define CRYPTO_SECRETKEYBYTES 122
#define CRYPTO_BYTES 639

// Change the algorithm name
#define CRYPTO_ALGNAME "DRS"

// Other Program specific constants
#define NB_ROUNDS (24)
#define _DIM_ (71)
#define _D_BOUND_ (71)
#define _SEC_LVL_ (16)
#define _BITS_D_BD (7)
#define LOG_LIMIT_M (28)
#define LIMIT_M ( ((int64_t)1) << (28) )
#define MSG_VECTOR_BYTES (258)
#define SEED_SIZE (32)
#define _SIZE_P_COEF (45)
// Secret Key Parameters
#define _NB_ONES_ (6)
#define _NB_B_ (3)
#define _B_VAL_ (11)
#define EXTRA_Z (32)

#endif
